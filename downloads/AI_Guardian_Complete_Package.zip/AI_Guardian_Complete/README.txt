AI Guardian — complete manuscript and review package

original_manuscript/ contains the uploaded manuscript files unchanged, including
PDF variants, main.tex, bibliography, figures, code, data, and the nested package.

review/ contains the complete five-phase review, proposed LaTeX replacements,
audit scripts/results, rendered evidence, and the LaTeX-fragment test harness.
review/evidence/latex-check/fragments.pdf is only a compilation of replacement
fragments for syntax checking; it is NOT a revised submission-ready paper.

The original manuscript has not been rewritten. Read the review for the changes
and experiments required before adopting the proposed replacement text.
