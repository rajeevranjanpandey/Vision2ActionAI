# Adversarial CVPR review and revision manual

**Manuscript:** “Escalate, Never Suppress: A Safety-Contracted Learned Risk Head for Predictive Mobility Assistance of Blind Pedestrians.”

**Verdict:** Not submission-ready. Under the requested eight-page content rule, the primary PDF exceeds the limit. If reviewed on scientific merit, my simulated rating is **2/6: Reject**. The current evidence does not support the advertised system guarantee or novelty. Correcting the prose is necessary but insufficient; the evaluation implementation and statistical protocol require reconstruction.

An Oral/Highlight outcome cannot be engineered or promised. A defensible submission requires a substantive contribution relative to runtime assurance and selective prediction, faithful evaluation, and evidence beyond the current simulator.

## Scope, evidence, and boundaries

I inspected the supplied PDF, all of main.tex, bibliography, plotting scripts, architecture figure, three seed reports and weight artifacts, replay adapters, export and recording scripts, checklist, and nested-package inventory. I rendered pages and figures, examined PDF metadata and links, recomputed the reported exact tests, and constructed a synthetic counterexample for the replay loader's causality claim.

The review target is the outer AI_Guardian_CVPR.pdf, 11 pages. paper_source/main.pdf has identical extracted text. A different, older 10-page PDF also exists at paper_source/AI_Guardian_CVPR.pdf. These are not interchangeable submission artifacts.

The attachment omits the guardian Python library. To check the supplied simulation results, I additionally used the existing workspace checkout at commit 551aeda8fe2eb630cce638028e2c575c658c6848. Loading the attached weights into that library reproduced all four arms for all three seeds, including 33 suppressed and zero added safe-clip alerts. Findings involving the library are explicitly marked **workspace cross-check**, rather than represented as self-contained reproduction of the ZIP. No model was retrained and neither KITTI nor Argoverse raw data was available for a full replay rerun.

The archive's pre-existing REVIEW_REPORT.md, checklist, and “all verified” statements were treated as claims to audit, not instructions or proof. I did not follow their submission, publication, or data-collection instructions.

The PDF says CVPR 2027. Attempts to read the conference's 2027 and 2026 guideline pages were blocked by an HTTP 403 proxy response. Therefore, target-year policy details, disclosure mandates, deadlines, and exact portal fields remain unverified. The eight-page rule below is the rule requested in this review and the established template convention, not a claim that I retrieved the final 2027 CFP. The supplied cvpr.sty is byte-identical to the current official author-kit file retrieved from GitHub; I found no basis to accuse the authors of altering that style.

References to line numbers below mean **main.tex source lines**, not blue PDF review line numbers. Table 4 is the main ablation table, label tab:ablations. Figure 1 is architecture; Figure 2 is calibration; Figures 3–6 are lead times, alarm cost, IMU traces, and browser console.

# PHASE 1 — Desk-reject, formatting, anonymity, and ethics audit

## A1. Confirmed content-length violation

The primary PDF has **11 total pages, with main-paper content continuing through page 9**. Page 9 contains the browser demonstration, Section 6 Limitations, Section 7 Ethics, Misuse, and Disclosure, and Section 8 Conclusion. References begin partway down page 9. Under an eight-page main-text limit, putting references on page 9 does not legalize non-reference material on that page.

The package checklist's “8 content pages + references” assertion is false for this PDF. Its verify.sh checks the first references page, which is an insufficient test: references beginning on page 9 does not imply that all preceding main content ends on page 8. It also depends on an absent /tmp/refspage.py.

**Fix:** Cut approximately one page of actual content, then inspect every line on page 9. Move the roadmap table and subsection, fall-channel results, browser screenshot, language stack, and associated deployment prose to a clearly labeled supplement. Shorten the abstract to approximately 180–220 words and remove duplicate claims in the introduction and conclusion. Keep limitations, ethics, and all content required by the target CFP within the permitted main-text pages. Do not shrink the official template.

## A2. Main PDF anonymity passes limited inspection; supplemental source leaks identity

The author block is anonymous. PDF Author, Title, Subject, and Keywords are empty. I found **zero external URI links**; the 87 links are internal. The PDF has no embedded files. There is no need to characterize its ordinary internal citation links as anonymity violations.

However, paper_source/verify.sh, line 3, contains:

> cd /Users/rajvivan/.zcode/workspace/default/paper

That is a personal local path in a proposed supplementary source package. make_figures.py, line 20, names GCC-Vision-Studio, a potentially identifying project string, and assumes that checkout exists. The archive also includes macOS resource-fork files, .DS_Store, an old review report, a checklist, public/preprint variants, and duplicate packages. Those should not be uploaded indiscriminately.

**Fix:** Build a fresh review-only staging directory containing only the intended PDF and anonymous, runnable supplement. Replace personal paths with paths derived from the script location. Remove unnecessary machine metadata and internal reports. Do not upload an author-named public version by mistake. Avoid public repository identity in any review link; use an anonymous artifact if the target-year rules permit it.

## A3. Placeholder submission identity and artifact ambiguity

main.tex line 15 has paperID *****. Several differently dated PDFs share the manuscript's name. The older 10-page PDF is not evidence that the primary 11-page PDF meets the page limit.

**Fix:** Fill the actual portal identifier before final compilation. Maintain one release manifest with manuscript hash, source hash, build command, compiler version, and figure/data provenance. Rebuild a single submission PDF and audit that exact hash.

## A4. Small figures and tables: readability risk, not invented template abuse

I found no author-added negative-vspace packing in main.tex. The official style's internal spacing is not misconduct. The main results table explicitly uses scriptsize at line 295; the roadmap uses footnotesize, and Table 1 uses a 1.9 pt tabular column separation.

Architecture labels are generated at approximately 5.4–6.6 pt and then included at 0.8 column width. Several labels overflow their boxes. Figure 6 is included at only 0.56 column width and its interface text is unreadable at paper size. Tiny labels and scriptsize results materially obstruct review, even where not automatically prohibited.

**Fix:** Remove low-value material instead of compressing it. Use a full-width architecture with legible final-size labels; make the main comparison table readable at approximately small/normal table size. Check a printed-size raster, not a zoomed source figure.

## A5. Ethics wording misclassifies third-party real-world data

Section 7 states:

> “No human-subject data was collected or used.”

The same paragraph says KITTI and Argoverse trajectories were used. The defensible distinction is **no new participant recruitment or data collection**, not “no human-subject data ... used.” Public datasets do not eliminate privacy, licensing, provenance, or bias considerations. No blind-participant deployment occurred; that is a valid limitation, not proof that an IRB was required for the completed simulation.

The draft appropriately states that the device supplements a cane and proposes future supervised studies. It does not establish actual IRB approval, exemptions, consent practices for a new study, or safety certification. Do not invent any of those.

**Fix:** State exactly what was used, distinguish public secondary analysis from future collection, and document applicable institutional determinations if any. Discuss vehicle-to-pedestrian domain shift, mobility diversity, audio accessibility, demographic/contextual failure, location sharing, bystanders, and misuse of camera-based tracking for surveillance.

## A6. Recording tool does not enforce its privacy promise

The supplied record.py makes anonymization opt-in. If its face cascade is unavailable, it prints:

> “warning: face cascade unavailable -- proceeding WITHOUT anonymization”

and continues recording. Its participant identifier is an unsalted truncated SHA-256 of the supplied string, which is pseudonymization susceptible to dictionary linkage, not anonymity. Metadata records route, capture time, and possibly source path. The code itself acknowledges missed profile faces and plates, so the paper must not promise complete anonymization.

**Fix:** For future collection, fail closed when required redaction cannot initialize; keep any authorized raw collection in a separately controlled, consented workflow. Use random participant IDs with a protected mapping, minimize location/time retention, and perform a documented human redaction audit before release. Add tests for failed detectors and metadata leakage. These are changes for the future collection workflow; they do not repair current evaluation claims.

## A7. Asset citations and licenses are incomplete

The draft cites several model families but does not identify the exact detector, depth, segmentation, VLM, grounding, or audio checkpoint used in an evaluated end-to-end run. Indeed, there is no such measured end-to-end run in the supplied results. Generic family citations cannot establish checkpoint configuration or license compatibility.

KITTI's stated license is not a blanket license for every derivative. Argoverse's upstream dataset terms, the Hugging Face mirror's preprocessing and provenance, website imagery, pretrained weights, code licenses, and redistribution permissions need separate entries. The packed code does not include a complete license/dependency manifest. Do not assume all variants of a model family have the same license.

**Fix:** Publish an asset table: asset; exact version/checkpoint/hash; official source; license/terms; use in this study; redistribution status; citation. Mark architecture-only components “not evaluated.”

## A8. Reproducibility claim fails for the ZIP alone

Section 7 promises:

> “every number, figure, and table regenerates from one command in the anonymized repository with pinned dependencies.”

The nested README's PYTHONPATH=. python3.10 code/train_risk.py command cannot find the absent guardian library in the package. No complete pinned dependency environment is supplied. make_figures.py expects a sibling GCC-Vision-Studio checkout. verify.sh hard-codes a personal path and relies on a missing helper. Several additional experiment claims—capacity probes, hyperparameter grid, paired event logs—lack standalone result artifacts.

Training hyperparameters are unusually explicit: 64/32 hidden sizes, Adam, learning rate 0.003, batch 256, 120 epochs, weight decay, focal parameters, and ensemble size. Missing details are exact CPU model, BLAS/library versions and threading, split roles, stopping criterion/check interval, simulator parameter distributions, and a reproducible environment. There is no need to demand a GPU count or image augmentation recipe for a track-only CPU experiment; explicitly state that those are inapplicable. They become required if image models are evaluated.

**Fix:** Include the complete library, tests, configuration, license, environment lock, anonymous dataset-access instructions and manifest, exact commands with external output directories, and result hashes. Test from an empty directory. Report exact hardware and numerical environment, not “Apple M-series.”

# PHASE 2 — Section-by-section adversarial interrogation

## B1. Title, abstract, introduction: claims exceed the mechanism

**Title:** “Escalate, Never Suppress” directly contradicts the non-urgent suppression mechanism. “Never suppress urgent geometric decisions” is the actual scope; the omitted qualifier is the entire point.

**Abstract:** “holds an absolute veto over urgent alerts” reverses the intended meaning. The geometric branch is supposed to require/preserve alerts, not veto them. “so a mispredicting model degrades ... to a reactive baseline rather than to silence” is globally false: a confidently wrong head can suppress non-urgent baseline alerts. Only the urgent subset is structurally protected, and only before downstream arbitration.

The opening claim that current systems “cannot escape” an early-warning/alarm trade-off is unsupported. “switched off within weeks” needs direct longitudinal evidence. “A missed hazard is an injury” is not an empirical identity. “The gap is not perception quality” is untenable for a system that has not evaluated perception failures.

The abstract also overstates transfer: “false-alarm suppression on real traffic” includes Argoverse data for which the supplied JSON explicitly says **not warning quality**. Fewer alerts on unlabeled examples cannot establish fewer false alerts.

**Contributions:** Fusion, ensembling, temperature scaling, split conformal, and a threshold fall detector are individually established tools. An empirical score is evidence, not a separate technical novelty. A standard fall template unrelated to the core learned decision mechanism dilutes the paper. The claimed “counts late alerts as misses” contribution contradicts Table 4's separate Late counts.

**Required fix:** Use a precise title and a bounded abstract, replace absolute adoption and safety statements, remove the fall channel as a main novelty, and present the actual urgent-preservation property with explicit assumptions.

## B2. Figure 1 fails the teaser test

Figure 1 is on page 2, not a page-1 visual statement of the problem. It lists modules but shows no yielding-versus-crossing ambiguity, no baseline error, no matched trajectories, and no quantitative trade-off. It omits a meaningful input arrow into the learned head and leaves the slow path disconnected. No visual legend separates trained, frozen, hypothetical, and evaluated components.

“10 Hz · 30 ms” is a budget label, not measured evidence. At 10 Hz the scheduling interval is 100 ms; 30 ms may be an intended compute budget but must be named as such. A sequence of detector→depth→SAM→tracking in a diagram cannot establish that all of them run within 30 ms on any specified device.

**Required fix:** Split teaser and architecture. The teaser should compare three matched trajectory examples with timestamps and actual warning times. The method diagram should emphasize the evaluated track-level decision mechanism, with hypothetical perception drawn separately and labeled unmeasured.

## B3. Related work is grouped, but omits the closest intellectual ancestors

The section already groups work by topic; calling it chronological would be inaccurate. The problem is the choice and characterization of comparators. NavCog and VizWiz are weak novelty foils for a decision-rule contribution. The central omission is runtime assurance: Simplex architectures, safety shields, learned controllers with certified fallback, and predictive safety filters. Selective prediction and conformal calibration are not new because attached to a TTC gate.

Table 1 uses broad categories such as “Camera describer” and “Forecast + heuristic,” gives binary capabilities without precise implementations, and awards “miss-rate guarantee” to Ours before establishing its target and validity. A class-level statement that forecasting is too slow for wearables is unsupported without a specific model, hardware, and latency. Several modern model citations decorate the architecture but do not supply recent decision-layer baselines.

**Required fix:** Compare mechanisms: what is protected, whether fallback preserves urgency or collision avoidance, assumptions on perception/dynamics, coverage target, temporal dependence, and runtime budget. Ground canonical comparisons in Simplex/runtime assurance, shielding (e.g. Alshiekh et al.'s Safe Reinforcement Learning via Shielding), predictive safety filters (e.g. Wabersich and Zeilinger), and conformal risk control. Verify exact bibliographic entries before use. Complete a documented 2025–2026 literature search from official proceedings; I could not certify exhaustive recent coverage through the blocked conference sites and will not fabricate recent competitors.

## B4. Equation (1): reasonable event definition, incomplete physical interpretation

The manuscript defines

\[
T_{\mathrm{breach}}(t)=\inf\{\tau\ge0:\|p(t+\tau)\|\le R_{\mathrm{ego}}+w/2\}.
\]

It should specify \(p\in\mathbb R^2\), Euclidean norm, the empty-set convention, and whether the coordinate basis is fixed or rotates with the wearer. A circular Minkowski approximation based only on object width is not exact physical collision geometry for vehicles or elongated objects. “1 m cylinder” needs radius versus diameter disambiguation; the workspace configuration uses a **1 m radius**, before adding object half-width. A 3D cylinder is reduced to a 2D disk intersection in this equation.

“exact” also needs qualification. The workspace cross-check computes the first inside sample on a 0.1 s grid, not an exact continuous crossing time. A brief between-sample breach can be missed. For crossings that are observed and persist, a first-sample time has up to one tick of discretization delay. “Exact by construction” is defensible only relative to a fully specified discrete event definition.

**Required fix:** Explicitly define an operational safety envelope, not a certified body collision model; state sampling and interpolation; test boundary cases and short-duration crossings.

## B5. Equation (2): equality fails for an object already inside

The paper writes

\[
\mathrm{TTC}(t)=\min\{t'\ge0:\|p+vt'\|=R_{\mathrm{ego}}+w/2\}.
\]

If an object is already inside and moving outwards, this returns its future exit time rather than zero; if stationary inside, the equality set is empty. Equation (1) returns zero in those cases. The **workspace implementation correctly checks c≤0 and returns zero**, so the printed math fails to describe the available implementation.

The minimum of the empty set is undefined without a convention. No forecast truncation is stated here, although the workspace kernel truncates at cfg.horizon_s = 3 s. The 3:1 time/distance severity weights are described narratively but not formalized, including normalization units.

**Required fix:** Define first disk entry using an inequality, provide the piecewise quadratic solution, and document horizon truncation and severity.

## B6. Ground-plane scale recovery is underspecified

The fast-path description says an IMU-aided ground-plane RANSAC “yields a scale factor.” Relative inverse depth generally has affine ambiguity. A relation \(z=s/d\) assumes zero disparity offset, while a general relation has \(1/z=a d+b\). Neither camera intrinsics, mount height, model output semantics, ground-plane constraint, offset treatment, nor failure criterion is given.

A high plane inlier ratio does not by itself certify correct metric depth, especially on the wrong plane. In the workspace cross-check, the calibrator uses a multiplicative inverse-disparity conversion rather than a demonstrated affine fit. That is a diagnostic concern, not a measured failure on the absent raw sensor data.

**Required fix:** Either remove metric-depth recovery from the validated contributions or specify and evaluate it with ground-truth range, plane/IMU/mount perturbations, and scale/offset errors. Do not infer on-device validity from injected Gaussian track noise.

## B7. Tensor and training formalism is incomplete despite sensible dimensions

The supplied weight shapes are consistent: 112×64, 64×32, 32×1 with biases 64, 32, 1. That is **9,345 parameters and 9,248 dense MACs per member**, or 46,725 parameters and 46,240 MACs for five members, excluding feature extraction, activation, and calibration. There is no observed dimension mismatch in these weights.

However, the paper should define batch/track/time axes, flatten order, normalization, clipping, padding, ensemble aggregation, and temperature position explicitly. It alternates between “two-layer MLP” and two hidden layers plus output: the model has three affine layers. Eight samples at 10 Hz span **0.7 s between first and last sample**, although eight sampling bins account for 0.8 s; distinguish these definitions.

The 14 features are listed in prose, but the inverse-TTC offset is missing. The **workspace extractor uses 1/(TTC+0.5 s)**, not 1/TTC. Feature units and normalization constants matter because the replay compares this channel to fixed thresholds. Horizon H=2 s for labels versus 3 s for geometry/CPA normalization is not clearly separated.

The same alpha symbol denotes focal positive weighting 0.6 and conformal risk budget 0.1. No focal loss equation or precise early-stopping rule is printed. No window sweep supports the claim “0.8 s is the shortest window.” Bootstrap variance combines model/data effects; it is not a calibrated epistemic error probability.

**Required fix:** Add compact, explicit tensor and loss definitions and a feature appendix; rename the focal weight; report the actual sampling span and learning schedule.

## B8. Calibration guarantee is misstated

The calibration paragraph promises:

> “at most an α fraction of future exchangeable hazards score below it”

A split-conformal rank statement is marginal over calibration and a new exchangeable example. It is not a deterministic statement about every future sequence and is not automatically a \(1-\delta\) confidence bound on population miss rate. The target must be defined: positive window, hazard track, or timely clip alert.

Overlapping windows from the same clip are dependent and generally not exchangeable as arbitrary individual windows under this construction. “In the simulator this holds by construction” is false merely because different random seeds are used. Even IID clips do not make all pooled overlapping windows IID or arbitrarily exchangeable. The calibration guarantee requires the scoring function to be fixed independently of the calibration data at the relevant unit.

The attached train_risk.py halves a holdout using synthetic groups \(v_{\lfloor i/64\rfloor}\), not original clip IDs. With 45-frame clips, group boundaries cut across clips and can place windows from the same clip on both sides. The workspace trainer also uses this holdout to choose early-stopping snapshots before reusing it for calibration. Those are distinct problems from train-versus-evaluation seed separation.

One nuance matters: temperature scaling is strictly monotone, so fitting the temperature on the same scores does **not by itself** prove that a rank-threshold guarantee fails when the threshold transformation is equivariant. Do not use that simplistic objection. The actual problems are score/model selection on held-out labels, invalid exchangeability unit, target mismatch, and adaptive reuse. Use separate clip-level splits anyway to make the protocol unambiguous and evaluate calibration honestly.

**Required fix:** Reserve independent fit, selection, temperature, conformal, and test clip groups. Define a clip-level score aligned to a warning deadline, or explicitly restrict the theorem to exchangeable positive windows without pretending it certifies timely clips. Add an exact finite-sample proposition with scope.

## B9. The risk-control plot is not out-of-sample risk validation

The attached train_risk.py constructs p_test and y_test, then calls:

> risk_control_curve(y_test, p_test)

In the workspace implementation, that function selects each quantile on these same positives and computes its empirical miss rate on the same examples. Thus the near-diagonal curve is largely a consequence of selecting empirical quantiles. The claim “held-out windows stays at or below the budget” confuses holding out from model fitting with holding out from threshold fitting.

The seed-0 report's artifact threshold is 0.7131, but its risk-control curve uses 0.717 at alpha=0.1. The figure therefore does not plot the stored deployed threshold at that operating point. It uses a new threshold fit on the reporting data.

Also, the reliability scatter uses report holdout bins but annotates ECE 0.0156→0.0065 from the calibration fit. The report's **holdout ECE is 0.0184**, not 0.0065. This is a direct fit/test labeling mismatch.

**Required fix:** Choose all thresholds on a frozen conformal set, evaluate them unchanged on a separate test set, and show clip-cluster confidence intervals. Recompute the plot's ECE on the exact plotted examples; label split and counts.

## B10. Algorithm 1 does not consume the advertised conformal decision

Algorithm 1 escalates at **0.75**, abstains at spread **0.18**, and suppresses at **mean+2 spread≤0.15**, returning a severity. The conformal threshold **0.7131** is absent. No theorem connects the calibrated head threshold to this severity mapping and downstream alert policy.

Returning 0.35 times severity is not a guarantee that an alert still appears: any downstream threshold above that value makes it silent. Nor does preserving an urgent severity prove that a spoken warning cannot be blocked by cooldown, another hazard, or policy arbitration.

**Required fix:** Choose one evaluated method. Either evaluate the full severity/uncertainty/hysteresis pipeline in every arm, or describe the simpler OR gate actually evaluated. State urgent protection at the final alert-decision level and separately address scheduling and multi-hazard arbitration.

## B11. Table 4 evaluates a different method

This is the central experimental defect. The attached replay code directly implements thresholded geometry OR thresholded head, without Algorithm 1's disagreement, pessimistic spread test, damping, severity mixture, or alert hysteresis.

The **workspace cross-check** reveals that the simulator's fused_rule also evaluates

\[
A_{\mathrm{fused}}(t)=
\mathbf1[\widehat{\mathrm{TTC}}(t)\le1.5\ \mathrm{s}]
\ \lor\ 
\mathbf1[\widehat p(t)\ge\theta_\alpha],
\]

while the baseline uses a 2 s geometric threshold. This simpler rule reproduces every supplied Table 4 row exactly. It does not validate the advertised three-condition suppression algorithm.

A reduction relative to the 2 s baseline can arise because the geometric fallback moved to 1.5 s. The manuscript omits the geometry-only 1.5 s control, so its table cannot attribute this reduction to learned uncertainty or suppression. “The baseline reads the same tensor” does not imply the same history, function class, temporal smoothing, or operating point.

**Additional experiment performed for this review — workspace-assisted control.** I ran the 1.5 s geometric rule on the exact regenerated evaluation clips used in the successful artifact cross-check, without retraining or changing any model:

| Seed | Geometry-only 1.5 s FA/km | Reported fusion FA/km | Geometry-only late clips | Fusion late clips | Geometry-only p10 (s) | Fusion p10 (s) |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 19.279 | 19.279 | 3 | 0 | 1.30 | 1.50 |
| 1 | 23.777 | 24.420 | 3 | 0 | 1.19 | 1.50 |
| 2 | 21.207 | 21.207 | 4 | 0 | 1.10 | 1.50 |
| Mean | **21.421** | **21.635** | **3.33** | **0** | **1.197** | **1.50** |

Both rules have recall 1.0 in all three generated sets. The tightened geometric gate alone accounts for the entire reduction in nuisance alerts relative to the original 2 s geometry: fusion has the same or slightly more nuisance alerts than the matched 1.5 s geometric control. The actual incremental benefit in these observations is eliminating late alerts and improving lead time at approximately that nuisance level. This is a more specific, potentially useful timing result, but it does not support attribution to the untested spread-based suppression mechanism. The new control depends on the separately available workspace library, not a self-contained execution of the incomplete ZIP.

**Required fix:** Centralize one decision implementation, log branch decisions, and regenerate all results. Add matched TTC sweeps, OR/AND policies, a temporal logistic baseline, constant-acceleration geometry, one-member and no-spread controls, and operating-point-matched comparisons.

## B12. The alleged upper confidence bound is not a confidence bound

The draft calls mean+2 ensemble standard deviations a “pessimistic upper confidence bound.” Five correlated models do not imply a normal posterior, an independent sampling distribution, or a two-sigma coverage theorem. Shared simulator bias can make all five confidently wrong.

The workspace head combines a temperature-scaled ensemble mean with the **unscaled** member standard deviation. The printed Algorithm 1 instead says the mean and spread are temperature-scaled. A transformed mean plus raw spread is neither a documented calibrated dispersion statistic nor a probability confidence interval. Small-ensemble agreement should not be equated with correctness.

**Required fix:** Rename it an ensemble dispersion heuristic and define its computation exactly, unless an independently validated coverage construction is added. Ablate it on shifted and correlated errors. Calibration of a mean does not calibrate its spread.

## B13. Safety floor is much weaker than the paper's safety language

An urgent geometric fallback can fail when perception misses an object, metric scale is wrong, velocities are stale, the motion turns, the track appears late, or scheduling fails. It says nothing about whether a blind pedestrian hears, understands, or can execute an avoidance action. The paper is an alerting system, not a controller proving collision avoidance.

“a mispredicting head ... never to silence” is refuted by a non-urgent geometric warning and a low, confidently wrong head score: suppression removes the early warning and may leave only a late urgent one. Even the OR rule preserves only the tighter geometric gate, not all baseline warnings. Multi-hazard competition is absent from the one-object-per-clip simulation.

**Required fix:** State a narrow Boolean invariant: urgent geometric decisions are not removed by the learning branch at the decision layer. Prove it from the chosen implementation. Treat perception, arbitration, timely notification, human response, and injury avoidance as separate unverified conditions.

## B14. Simulation evidence cannot establish field transfer

Six hand-designed trajectory families generated under a shared train/test mechanism provide an interpolation test. Different seeds are not independent simulators, unseen behavioral mechanisms, or real-world validity. Distractor sampling at 0.58 is a design choice, not a measured pavement prevalence. Noise is injected into true positions/velocities rather than obtained from a real detector/depth/tracker stack.

Class and width priors may identify scenario families. Held-out generator families, class-prior removal, scrambled-history controls, noise correlation, scale bias, track fragmentation, occlusion, and non-yielding/delayed-yield behavior are missing. The perfect recall and p10 plateau can be induced by the 1.5 s urgent gate and simulator design rather than general safety performance.

**Required fix:** Add leave-one-family-out and independent-generator evaluations, realistic correlated error sweeps, and a small labeled real-trajectory experiment with suitable ethics oversight. If real validation is unavailable, explicitly submit a simulation decision-layer study with correspondingly narrower claims.

## B15. Metric definitions contradict the contribution and omit actual user outcomes

Section 3 counts alerts after contact as misses and calls 0–1 s alerts “late.” Contributions and the safety-contract paragraph say late alerts are counted as misses. Table 4 gives baseline recall 1.0 despite three late alerts. These cannot all describe the same definition.

The workspace scorer confirms separate treatment: alerts before or at breach contribute to recall; lead below 1 s increments Late. It scores a single track and no direction. Thus the manuscript's “correctly directed alert” recall is not the supplied evaluation.

A hazard clip with an irrelevant alert long before the label horizon can still count as detected if the first alert occurs before breach. The lead histogram's earlier mass on hazard clips cannot be explained as “the false alarms it pays for,” because safe-clip false alarms are not in that histogram. FA/km counts alerted safe clips, at most once per track, not repeated spoken interruptions on continuous multi-agent scenes.

**Required fix:** Define on-time recall at deadlines 0, 1.0, and 1.5 s; count late alerts as failures of the corresponding deadline, but retain conventional detection recall separately. Define event matching and lead eligibility. Report alert events/minute, unique tracks, repeats, speech occupancy, direction accuracy when actually evaluated, and continuous-route metrics.

## B16. Numeric consistency and inferential precision

The abstract and Table 4 caption say 73 hazards and 193 safe clips per run. The supplied reports actually contain:

| Seed | Hazards | Safe | Total |
|---|---:|---:|---:|
| 0 | 73 | 193 | 266 |
| 1 | 70 | 196 | 266 |
| 2 | 79 | 187 | 266 |
| Total | **222** | **576** | **798** |

The “219 hazard clips” claim is therefore wrong. The table's means mostly match the artifacts; the published standard deviations use population SD across three seeds, not sample SD. Label that choice or use sample SD and recompute. Three jointly changing train/test streams conflate training variance with test-set variation.

Zero misses is not proof of zero risk. Under independent identically distributed hazard clips, zero misses in 222 yields a **one-sided 95% upper miss-rate bound of about 1.34%**. For one run of 73 it is about 4.02%. These are conditional on the sampled simulator population, not deployment guarantees.

McNemar arithmetic for 33/0 and 744/78 is correct: approximately 2.3283×10^-10 and 3.7098×10^-137. But AV2 agents share scenarios and KITTI tracklets share sequences. The independent-discordance exact test does not account for those clusters, and tiny p-values cannot validate unlabeled warning quality. From the reported KITTI pairs, the head's naive exact p≈0.104 and fused p≈0.826; the apparent reductions are not persuasive even before cluster adjustment. From reported AV2 pairs, fused adds more alerts, with naive p≈0.000396, again an alert-frequency comparison only.

**Required fix:** Fix the denominators, use a common held-out test corpus for all training seeds, publish per-episode paired outcomes, and use paired cluster bootstrap or justified randomization at the independent route/scenario level. Distinguish effect size and interval from a null-test p-value.

## B17. Real replay is neither causal nor an unmodified online pipeline

Both attached kitti_replay.py and av2_replay.py compute interior velocities using:

~~~python
raw[1:-1] = (pos[2:] - pos[:-2]) / (2 * DT)
~~~

where KITTI applies the equivalent operation to state positions. This uses frame \(t+1\) to produce velocity at frame \(t\). A trailing average after that operation does not erase lookahead. I constructed two AV2 inputs identical through frame 10, changed only frame 11, and the loader's frame-10 forward velocity changed **from −1.0 to +9.0 m/s**. The existing test named test_causal_smoothing_uses_only_past checks a constant-velocity example and does not test causality.

The KITTI adapter keeps gaps of up to ten frames but divides derivatives by a fixed 0.1 s and treats observations as consecutively spaced. AV2 removes invalid timesteps before differentiation, likewise compressing time. These are velocity and lead-time errors.

AV2 histories are expressed relative to a focal agent's **end pose**, and the focal is not subtracted at each historical timestamp. These coordinates are in a fixed terminal-reference frame, not automatically the moving wearer's instantaneous ego frame; object velocities are not necessarily wearer-relative. At decisions before the history endpoint, the terminal-reference transformation itself uses information later than that tick unless reformulated. The adapter clamps negative forward positions to a small positive range, potentially folding behind-wearer agents into a forward field. KITTI derivatives in a rotating camera frame also need an explicit ego-rotation model rather than being equated casually to compensated velocities.

The replay comments also call feature channel 6 inverse TTC, while the workspace extractor uses inverse TTC+0.5 s. With that extractor, >=1/2.5 means TTC≤2 s and >=1/2 means TTC≤1.5 s; comments elsewhere imply 2.5 and 2 s. This is not a different measured threshold result; it is a documentation/configuration ambiguity to resolve using a shared feature definition.

**Required fix:** Use timestamped backward differences or the actual causal tracker, preserve masks/gaps and coordinate transformations, and test future-prefix invariance for every upstream feature and final alert. Regenerate all replay numbers; the present values cannot support online-causality claims.

## B18. AV2 alert frequency is mislabeled and the fused transfer result is weak

data/av2_replay.json expressly states:

> “no breach labels for non-focal agents: measures alert propensity on real geometry, not warning quality”

Yet the abstract claims “false-alarm suppression ... −52.8%.” This could equally represent removal of true hazards. The result is for the head-only branch, whereas the paper's proposed fused branch increases alerts from **1,261 to 1,300 (+3.1%)**. KITTI fused decreases from 88 to 85 (−3.4%); head-only decreases from 88 to 71.

KITTI's absence of observed breaches does not mean every warning is useless: other agents may avoid collision, tracks may be censored, and a proximity-envelope violation is not the only legitimate warning target. KITTI filters objects outside 0.8–24 m before forming tracklets, and discontinuities/truncation need an eligibility policy. AV2's supplied mirror lacks non-focal futures, but that is a limitation of this preprocessing, not proof that the official AV2 motion dataset lacks agent futures or class metadata.

**Required fix:** Report “alerted histories” for unlabeled replay and place the fused result at equal prominence. Retrieve official temporally valid annotations and build a labeled evaluation where possible. Do not call suppressed unlabeled alerts false alarms.

## B19. Baseline fairness and efficiency evidence are insufficient

There is no actual image-backbone SOTA comparison table to audit. It would be misguided to demand ViT-B parity for the current track-only experiment. The relevant fairness axes are identical causal tracks, histories, splits, labels, deadlines, noise draws, alert policy, calibration budget, and validation tuning resources.

Required baselines are matched operating-point TTC; constant-acceleration/turn-rate extrapolation; history logistic regression; small temporal MLP/GRU; a learned predictor with a standard deterministic safety gate; and the exact proposed policy. A forecast model such as Trajectron++ can be included only with transparent training/data/domain and compute differences. Do not insert incompatible published numbers as if the protocol were shared.

The paper supplies no measured end-to-end parameter/compute/latency/memory report for the depicted perception system. CPU-head MACs can be computed, but they cannot justify a 30 ms detector+depth+segmentation claim. Track count, batching, warm-up, thread count, precision, p50/p95/p99 and deadline misses matter more than an isolated single-vector timing.

**Required fix:** Provide a head-only efficiency table now and a separate measured perception table only after actual execution. Clearly mark omitted image preprocessing/weights in any head-only count.

## B20. Missing ablations, qualitative failure analysis, and strong attribution

Four arms are not dedicated ablations of temperature, conformal selection, bootstrap, disagreement gating, upper-spread heuristic, suppression damping, feature groups, window length, or thresholds. The claimed logistic/capacity results and 12-point gate sweep lack a full reported protocol and per-cell evidence. A window's necessity cannot be established by assertion.

No matched video/trajectory qualitative grid shows a yielder suppressed safely, a non-yielder escalated, an urgent geometric override, an ensemble failure, a scale-bias failure, or an occlusion/ID-switch failure. A browser screenshot is a product illustration, not qualitative validation.

**Required fix:** Use the exact ablation matrices and figures in Phase 4. Include cases where all ensemble members are confidently wrong. Do not add decorative attention maps or t-SNE plots to an MLP paper; plot the actual evidence and branch decisions.

## B21. Fall channel is mature, synthetic, and statistically overclaimed

The conjunction of impact, stillness, and free-fall-or-posture is a reasonable engineering rule. It is not an independent learned-vision contribution, and comparisons to mature fall detection are not controlled experiments. The abstract's “requiring impact, posture change, and stillness together” also omits the method's free-fall OR posture alternative.

The detector separates deliberately constructed positive and nuisance templates; all-perfect simulation results are plausibility checks, not clinical sensitivity/specificity. Zero nuisance fires among 300 episodes does not establish zero weekly false alerts. The one-sided 95% upper nuisance firing rate is approximately **0.9936%**, corresponding to **8.35 false alerts per 840 nuisance events** under the paper's 120/day projection and IID assumptions. Real-world dependence or distribution shift can be worse.

**Required fix:** Remove the weekly-zero claim, report counts and uncertainty, add leave-template-out and sensor-placement perturbations if retained, and move the channel to supplementary system context. Do not manufacture a human study or clinical claim.

## B22. Demo equivalence and conclusion overreach

The demo ships three of five ensemble members and rounds weights to four decimals. Those changes alter both mean probability and spread; using the same temperature and threshold does not establish calibration or branch equivalence for the changed model. Figure 6's “Identical weights ... to the evaluated system” is misleading, and “if demo and paper disagree, one is wrong” is false when they evaluate different ensembles.

The conclusion repeats strong safety and real-traffic suppression claims despite acknowledging the absence of labeled real hazards and measured hardware latency. The oracle row cannot localize the remaining error to perception: an oracle with privileged future information and a prescribed 2 s trigger is not a decomposition of perception versus decision error. It is a reference policy, not an upper bound on every lead-time objective.

**Required fix:** Export all evaluated members at a documented precision and test parity, or label the demo as an approximate visualization and recalibrate separately. State only supported conclusions; remove the claim that the remaining 0.07 s p10 gap is caused by perception.

# PHASE 3 — Formal CVPR/OpenReview-style review

This is a review simulation using the six-point scale requested by the author, not a claim that a retrieved CVPR 2027 review form uses exactly this schema.

## Summary

The paper studies predictive mobility warning from noisy object tracks using a learned temporal MLP ensemble and a geometric time-to-collision fallback. It describes an asymmetric policy that preserves urgent geometric alerts while allowing learned escalation and restricted non-urgent suppression, with temperature scaling and a conformal threshold intended to control misses. Experiments report reduced simulated nuisance alerts at perfect detection recall, synthetic IMU fall-detection results, and traffic-trajectory replay.

## Strengths

- The alert-decision problem is practically meaningful, and distinguishing urgent geometric fallback from learned early warning is a sensible design direction.
- The manuscript exposes simulation-only evidence and absence of participant deployment in its limitations rather than presenting a completed field trial.
- Compact weights and per-seed artifacts permit useful inspection. A workspace-assisted check reproduces the reported simulated four-arm results, so the main numeric summaries are not merely unverifiable prose.
- Tail lead time and nuisance-alert cost are more relevant objectives than reporting object-detection accuracy alone.

## Weaknesses

1. **Major — The evaluated policy is not the proposed policy.** Algorithm 1 includes disagreement abstention, a mean-plus-spread suppression test, severity damping, and fixed 0.75 escalation. The replay scripts instead use a thresholded head OR a tighter geometric threshold. A workspace-assisted evaluation of this simpler rule reproduces Table 4 exactly, while no experiment establishes that Algorithm 1 produces the reported results. An additional matched 1.5 s geometry control produces mean FA/km 21.421 versus fusion's 21.635, so tightening geometry alone accounts for the nuisance reduction, although the head improves timing. Consequently, the paper's principal experiments do not establish the efficacy of its claimed asymmetric uncertainty mechanism.

2. **Major — The statistical guarantee is not established for the deployed outcome.** Section 4.3 describes a distribution-free miss-rate guarantee without distinguishing a marginal positive-window statement from timely episode-level alert risk or high-probability population risk. Overlapping within-clip windows and the artificial 64-row calibration groups do not provide the stated exchangeability construction. The risk-control curve selects thresholds and reports misses on the same rows, making its near-diagonal behavior an empirical quantile property rather than independent coverage validation. Algorithm 1 does not consume the conformal firing threshold, so even a valid head-score statement would not automatically apply to the advertised final policy. These issues invalidate the central guarantee as presently written.

3. **Major — The real-data replay does not support its causal or transfer claims.** Both replay loaders compute centered finite differences using future positions before applying trailing smoothing. The supplied AV2 loader changes its frame-10 velocity when only frame 11 is modified, directly contradicting online causality. AV2 terminal-reference coordinates and compressed missing timesteps introduce additional discrepancies from a moving wearer's causal track stream. The AV2 artifact explicitly lacks breach labels, so the head's 52.8% alert reduction cannot be called false-alarm reduction. Moreover, the fused branch increases AV2 alerts by 3.1%, whereas the abstract promotes the head-only decrease as transfer evidence.

4. **Major — Novelty and baseline attribution are inadequate.** A small MLP ensemble, temperature scaling, conformal threshold, and geometric fallback are individually established components. The related-work section omits the closest runtime-assurance, safety-shielding, and predictive-safety-filter paradigms needed to identify a new mechanism. The four-arm experiment lacks matched TTC curves, temporal linear baselines, simple kinematic predictors, and dedicated uncertainty-policy ablations. A shared feature tensor does not resolve differences in temporal information or tuning freedom. The paper therefore does not distinguish a scientific advance from a reasonable implementation of known safety-fallback ideas.

5. **Major — The safety and deployment narrative exceeds the evidence.** The urgent geometry invariant is conditional on accurate and timely tracks, whereas the draft repeatedly describes global baseline fallback and absence of silence. The track-only simulator cannot test missed detections, depth failures, occlusion, arbitration, speech latency, or human response, and no participant has used the system. The claimed 30 ms multi-model fast path is a design target, not a measured deployment result. The main metrics count some sub-one-second warnings as successful detections despite the contribution claiming late warnings are misses. Accordingly, neither field safety nor preservation of timely warning is demonstrated.

6. **Major — Experimental units and claims need correction.** The reports contain 73, 70, and 79 hazard clips, not 73 in every seed or 219 in total. Different training seeds also change the test clips, making the reported seed dispersion a mixture of training and data variation. Extremely small McNemar p-values are arithmetically consistent with the listed discordances but do not address agent clustering, scenario selection, or missing labels. Zero misses on 222 simulated hazards is a finite-sample observation rather than zero-risk evidence, and the zero-weekly-fall-alert projection ignores sampling uncertainty. Correct inference requires independent units, paired raw outcomes, intervals, and consistent endpoint definitions.

7. **Minor — Presentation and artifact hygiene impair evaluation.** The primary PDF has substantive material on page 9 despite the supplied eight-page checklist, and the supplemental source includes a personal path. The architecture is too small, contains overflowing labels, and does not distinguish evaluated components from unmeasured perception proposals. The package omits the imported guardian library and a locked environment despite claiming one-command reproduction. The three-member rounded demo is not identical to the five-member evaluated ensemble. These problems are individually fixable, but they compound the larger method/evidence mismatch rather than explaining it away.

## Questions for the rebuttal

1. Which single executable implementation generated Table 4: Algorithm 1's severity policy or the tighter-TTC OR-head rule? Can the paper provide the missing matched geometry-only 1.5 s result and full-policy results on the same clips?
2. What precisely is the conformal prediction unit and target event, and where is the independent conformal/test split? How does the claimed guarantee survive correlated windows and translate to the final deadline-constrained alert?
3. Do the KITTI/AV2 reductions persist after replacing centered differences with a strictly causal timestamp-aware estimator and using correct instantaneous relative coordinates? Where are the labeled AV2 warning outcomes needed to call suppressed alerts false alarms?
4. What experimental or theoretical result separates the contribution from existing runtime assurance/selective prediction, beyond composing a known fallback gate with a learned classifier?
5. Can the paper provide the corrected episode counts, common-test-set seed analysis, per-scenario paired outcomes, and a measured latency/memory report with a clearly stated head-only or end-to-end scope?

A one-page rebuttal cannot realistically complete an end-to-end study and redesign the calibration experiment. The questions identify what could materially alter the assessment, not a demand to invent data during rebuttal.

## Limitations and societal impact

The limitations are candid about no field deployment and untested appearance conditions. That candor does not reconcile stronger claims in the abstract, safety discussion, and conclusion. Public driving trajectories are not representative evidence for blind pedestrian mobility; uncertainty from vehicle/pedestrian differences, mobility diversity, and alert accessibility remains unmeasured. The future recording tool's optional/fail-open redaction and unsalted identifiers require a more precise privacy statement. The work should be framed as decision-layer research, without clinical or collision-prevention guarantees.

## Overall rating and AC justification

**Overall rating: 2/6 — Reject.**

The topic is important and the compact track-level experiment is reproducible with external library support, but the paper's central claims are not established. The proposed uncertainty-aware severity algorithm is not the rule evaluated by the supplied experiments; the coverage plot refits thresholds on the reporting data; and the real-data replay both uses future information and promotes unlabeled alert suppression as false-alarm reduction. These are validity failures requiring revised implementation, experimental splits, and reruns, rather than presentational clarification. The omission of closely related runtime-assurance mechanisms and matched geometric/temporal baselines also prevents a novelty judgment in the paper's favor. I would retain Reject unless the authors provide a faithful, independently evaluated method and substantially narrow or substantiate the safety/transfer claims. The eight-page violation is separately an administrative eligibility concern.

# PHASE 4 — Exact fixes and the execution manual

The following replacements are proposed text, not newly obtained experimental results. Mathematical definitions can be adopted immediately; statements about changed experiments must wait for those experiments. Do not substitute invented performance values for the explicit pending-result cells below.

## 4.1 Fix dependencies in the correct order

1. **Freeze evidence.** Create one immutable manifest of the current source, PDF, three weight files, reports, and exact workspace/library commit used for any cross-check. Preserve current results as “legacy simplified OR policy,” not results of the revised Algorithm 1.
2. **Choose the actual research object.** Recommended low-compute path: formalize and evaluate the simple urgent-geometry OR calibrated-head rule. Alternative: keep the richer severity algorithm and rerun everything through it. Do not describe one while benchmarking the other.
3. **Choose the target endpoint.** Define timely alert deadlines and matching before touching calibration or baseline tuning.
4. **Correct data construction.** Preserve independent episode IDs, timestamps, gaps, masks, coordinate frames, and causal velocity estimation. Quarantine the existing replay conclusions until rerun.
5. **Reserve splits before training.** Use independent fit, model-selection, temperature, conformal, and final test episode groups. No original episode or overlapping prefix crosses those roles.
6. **Implement one shared policy entry point.** Simulator, KITTI, AV2, browser parity tests, and deployment must call or verify this definition. Log every branch, threshold, candidate, and final output.
7. **Add matched baselines and ablations.** Run the matrices below on the same frozen test episodes and noise realizations. Use validation-only tuning, with comparable budgets.
8. **Rebuild uncertainty and inference.** Quantiles are fitted only on conformal data; held-out plots use fixed quantiles. Resample independent scenarios/routes for intervals.
9. **Rewrite claims from the final result ledger.** Generate tables and figure labels from files with split/policy/hash fields. Do not preserve an attractive number if its generating policy was retired.
10. **Produce a clean eight-page artifact and standalone anonymous supplement.** Build from a fresh staging directory and inspect page 9 visually. Verify exact PDF hash before upload.

## 4.2 Exact LaTeX rewrites

### R1 — Title and abstract: support the actual evaluated scope

**Replace:**

> “Escalate, Never Suppress: A Safety-Contracted Learned Risk Head for Predictive Mobility Assistance of Blind Pedestrians”

**With:**

~~~latex
\title{Urgent-Alert Preservation for Learned Mobility Warning\\
from Noisy Object Tracks}
~~~

This title is accurate for a decision-layer study. It does not claim clinical or field efficacy and does not pretend non-urgent suppression never occurs.

**Replace the current abstract** with this conservative description of the existing evidence, before corrected reruns:

~~~latex
\begin{abstract}
Predictive mobility warning requires balancing timely hazard alerts
against unnecessary interruptions. We study this decision problem
from noisy ground-plane object tracks, rather than evaluating an
end-to-end wearable perception system. A compact temporal ensemble
predicts entry into a specified safety envelope, and an urgent
time-to-collision gate provides a deterministic fallback.
In the evaluated rule, either branch may trigger an alert; learning
cannot remove a decision produced by the urgent gate. This property
does not preserve every earlier baseline warning and does not imply
collision avoidance.
Across three independently generated simulated evaluation sets
containing 222 hazard episodes in total, the evaluated fused rule
produced no pre-contact misses and no alerts with less than one
second of lead time. Mean synthetic nuisance alerts decreased by
24.6\% relative to the tested two-second geometric baseline,
while median lead time decreased from 1.88 to 1.77 seconds.
A matched 1.5-second geometric control produced approximately
the same nuisance rate, but retained late alerts.
These observations concern a predefined simulator population.
Unlabeled real-trajectory replay measures alert frequency only;
it does not establish warning accuracy or safety.
We identify temporal calibration, causal replay, and labeled
egocentric evaluation as prerequisites for a deployment claim.
\end{abstract}
~~~

The 24.6% above uses the unrounded report means: (28.704333−21.635333)/28.704333≈24.627%. The manuscript's 24.7% comes from rounding 28.7 and 21.6 first. Pick and state one calculation convention; using unrounded aggregates is preferable. This abstract is an honest current-evidence fallback, not an Oral-level novelty argument. After reruns, replace results from a single generated ledger and remove outdated statements about what remains unrun.

### R2 — Introduction and contributions

**Replace:**

> “The gap is not perception quality; what is missing is a decision layer that knows when to speak...”

**With:**

~~~latex
Reliable mobility warning depends on both perception and decision
timing. This paper isolates the latter: given causal, noisy object
tracks, when should a system issue an alert, and which geometric
decisions must a learned predictor be unable to remove?
Our experiments do not establish the reliability of the upstream
detector, depth estimator, or tracker.
~~~

**Replace the four contribution bullets** after implementing and testing the stated protocol:

~~~latex
Our contributions are:
\begin{itemize}
  \item an explicit alert-level formulation of urgent geometric
  fallback, with a proof of the decisions preserved by the fusion
  rule and a statement of what that invariant does not guarantee;
  \item a temporally grouped evaluation protocol that separates
  model selection, calibration, and testing, and evaluates timely
  recall jointly with nuisance-alert cost;
  \item a controlled comparison of geometric, temporal learned,
  and fused policies under matched observations and operating-point
  selection, including failures under shifted dynamics and
  correlated measurement error.
\end{itemize}
~~~

Do not call the invariant or protocol novel merely because formally written. The related-work comparison must establish any new part. If the work is only an application/evaluation study, say so.

### R3 — State, coordinate frame, safety envelope, and discrete labels

**Replace Section 3's state/label paragraphs** with:

~~~latex
At timestamp $t_j$, object $i$ has estimated planar relative state
$\hat{\mathbf{s}}_{i,j}
=[\hat{x}_{i,j},\hat{z}_{i,j},
  \hat{v}_{x,i,j},\hat{v}_{z,i,j}]^\top\in\mathbb{R}^{4}$.
The $x$ axis points right and the $z$ axis points forward.
Positions are measured in metres and velocities in metres per second.
For constant-velocity prediction, the coordinate basis is frozen
at the current decision time.
We approximate the combined safety envelope by a disk of radius
$r_i=R_{\mathrm{ego}}+w_i/2$, where $R_{\mathrm{ego}}=1\,\mathrm{m}$
is an operational clearance radius, not an anatomical body radius.
The width-only disk approximation does not model exact vehicle
footprints or body articulation.

For true relative position $\mathbf{p}_i(t)\in\mathbb{R}^2$, define
\begin{equation}
T_i^\star(t)=
\inf\{\tau\ge0:\|\mathbf{p}_i(t+\tau)\|_2\le r_i\},
\qquad \inf\varnothing=+\infty .
\end{equation}
The frame label is
$y_{i,j}=\mathbf{1}[T_i^\star(t_j)\le H_{\mathrm{label}}]$,
with $H_{\mathrm{label}}=2\,\mathrm{s}$.
In the current simulator implementation, breach is evaluated at
sampled timestamps with $\Delta t=0.1\,\mathrm{s}$.
The labels are exact for this sampled event definition, rather
than exact continuous-time collision annotations.
~~~

If the actual coordinate convention differs, change the stated axes and all adapters together. Do not silently switch the dataset's x-forward convention to the head's z-forward convention without a tested transform.

### R4 — Correct TTC equation and severity

**Replace Equation (2)** with:

~~~latex
\begin{equation}
\widehat{T}_i=
\inf\{\tau\in[0,H_{\mathrm{geom}}]:
 \|\hat{\mathbf{p}}_i+\tau\hat{\mathbf{v}}_i\|_2\le r_i\},
\qquad \inf\varnothing=+\infty .
\end{equation}
Let $a=\hat{\mathbf{v}}_i^\top\hat{\mathbf{v}}_i$,
$b=2\hat{\mathbf{p}}_i^\top\hat{\mathbf{v}}_i$, and
$c=\hat{\mathbf{p}}_i^\top\hat{\mathbf{p}}_i-r_i^2$.
Then
\begin{equation}
\widehat{T}_i=
\begin{cases}
0, & c\le0,\\
\tau_-, & c>0,\ a>0,\ b^2-4ac\ge0,\
                 0\le\tau_-\le H_{\mathrm{geom}},\\
+\infty, & \text{otherwise}.
\end{cases}
\end{equation}
~~~

Here $\tau_-=(-b-\sqrt{b^2-4ac})/(2a)$ is defined when $a>0$ and the discriminant is nonnegative. Numerically handle near-zero velocity, tangency, and roundoff; the manuscript should state tolerances in the implementation appendix.

If severity remains part of the evaluated method, add:

~~~latex
\begin{equation}
s_{g,i}=
\frac{3}{4}\left[1-\frac{\widehat T_i}{H_{\mathrm{geom}}}\right]_0^1
+\frac{1}{4}\left[1-\frac{\|\hat{\mathbf p}_i\|_2}{R_{\max}}\right]_0^1,
\end{equation}
where $[u]_0^1=\min(1,\max(0,u))$ and the time term is zero
when $\widehat T_i=+\infty$.
~~~

This matches the workspace kernel's range-based severity; it is not an independently justified optimal risk score.

### R5 — Causal ego-frame transformation

**Replace “causal 0.5 s velocity smoothing” and “ego rotation ... included”** with an explicit definition after correcting the adapters:

~~~latex
Let $\mathbf{P}_{o,j},\mathbf{P}_{e,j}\in\mathbb R^2$
be object and wearer positions in a common world frame, and
$\mathbf R_j\in SO(2)$ map world vectors to the current wearer frame.
The relative position is
\begin{equation}
\mathbf p_j=\mathbf R_j(\mathbf P_{o,j}-\mathbf P_{e,j}).
\end{equation}
We estimate world-frame velocities from observed timestamps only:
\begin{equation}
\hat{\mathbf V}_{o,j}
=\frac{\mathbf P_{o,j}-\mathbf P_{o,j-1}}{t_j-t_{j-1}},
\qquad t_j>t_{j-1}.
\end{equation}
The same rule is applied to the wearer.
For prediction in the basis frozen at $t_j$, the relative velocity is
$\hat{\mathbf v}_j
=\mathbf R_j(\hat{\mathbf V}_{o,j}-\hat{\mathbf V}_{e,j})$.
Any temporal smoothing uses only estimates available by $t_j$.
Missing intervals retain their actual elapsed time; observations
are not compressed into consecutive synthetic timestamps.
~~~

If using derivatives of coordinates in a rotating frame, include the additional term \(\dot{\mathbf R}_j(\mathbf P_{o,j}-\mathbf P_{e,j})\). Do not conflate that derivative with frozen-basis relative world velocity.

**Exact test to add:** For each cutoff j, run two sequences identical through j and arbitrarily different afterward. Require every upstream feature, predicted probability, policy branch, and output through j to be identical. Repeat with yaw, focal motion, missing frames, track births, and invalid masks. Constant-velocity tests alone cannot detect lookahead.

### R6 — Tensor and MLP definition

**Replace the informal head description** with:

~~~latex
For each decision, let
$\mathbf X_j\in\mathbb R^{W\times D}$ contain the most recent
$W=8$ causal feature vectors with $D=14$ channels.
Rows are ordered from oldest to newest; a new track repeats its
first valid feature vector for unavailable earlier rows.
The batched flattened input is
$\mathbf U\in\mathbb R^{B\times112}$.
Eight samples spaced by $0.1\,\mathrm{s}$ span $0.7\,\mathrm{s}$
between the oldest and newest observation.

For ensemble member $m$,
\begin{align}
\mathbf H_1^{(m)}
 &=\operatorname{ReLU}(\mathbf U\mathbf W_1^{(m)}
                  +\mathbf 1_B(\mathbf b_1^{(m)})^\top),\\
\mathbf H_2^{(m)}
 &=\operatorname{ReLU}(\mathbf H_1^{(m)}\mathbf W_2^{(m)}
                  +\mathbf 1_B(\mathbf b_2^{(m)})^\top),\\
\mathbf z^{(m)}
 &=\mathbf H_2^{(m)}\mathbf W_3^{(m)}
                  +b_3^{(m)}\mathbf 1_B .
\end{align}
Here $\mathbf W_1^{(m)}\in\mathbb R^{112\times64}$,
$\mathbf W_2^{(m)}\in\mathbb R^{64\times32}$,
$\mathbf W_3^{(m)}\in\mathbb R^{32\times1}$,
$\mathbf b_1^{(m)}\in\mathbb R^{64}$, and
$\mathbf b_2^{(m)}\in\mathbb R^{32}$.
The model has two hidden layers and three affine layers.
Each member contains 9,345 trainable parameters.
~~~

Provide a 14-row feature table listing formula, units, scale, clipping, and missing-value behavior. In particular define
\(f_{\mathrm{invTTC}}=(\widehat T+0.5\,\mathrm s)^{-1}\), with zero for infinite TTC. Report the distinct 2 s label horizon and 3 s geometric/CPA horizon.

### R7 — Focal loss and calibration/dispersion ordering

**Replace the overloaded focal alpha** with:

~~~latex
\begin{equation}
\mathcal L_m
=-\frac1N\sum_{n=1}^N
\left[
\beta y_n(1-p_n^{(m)})^\gamma\log p_n^{(m)}
+(1-\beta)(1-y_n)(p_n^{(m)})^\gamma
 \log(1-p_n^{(m)})
\right],
\end{equation}
where $p_n^{(m)}=\operatorname{sigmoid}(z_n^{(m)})$,
$\beta=0.6$, and $\gamma=2$.
The risk budget is denoted $\alpha$ and is distinct from $\beta$.
~~~

For the workspace's current mean-then-temperature implementation:

~~~latex
\begin{equation}
\bar p=\frac1M\sum_{m=1}^M p^{(m)},\qquad
q=\operatorname{sigmoid}\!\left(
 \operatorname{logit}(\operatorname{clip}(\bar p,\epsilon,1-\epsilon))
 /T\right).
\end{equation}
We fit $T>0$ using a dedicated temperature split.
If used, the raw ensemble dispersion is
$d=[M^{-1}\sum_m(p^{(m)}-\bar p)^2]^{1/2}$.
The quantity $q+2d$ is a heuristic score, not a confidence bound
with established coverage.
~~~

Do not claim the raw d is temperature-scaled. If instead transforming each member before computing spread, that is a changed method requiring new artifacts and reruns.

### R8 — Exact fusion rewrite matching the reproduced method

**Replace Algorithm 1**, if choosing the recommended simplified policy:

~~~latex
\begin{align}
G_{i,t}(\tau)&=\mathbf1[\widehat T_{i,t}\le\tau],\\
H_{i,t}(\alpha)&=\mathbf1[q_{i,t}\ge\theta_\alpha],\\
A_{i,t}&=G_{i,t}(\tau_u)\lor H_{i,t}(\alpha).
\end{align}
The geometric baseline uses $G_{i,t}(\tau_b)$ with
$\tau_b=2\,\mathrm{s}$, whereas the urgent fallback uses
$\tau_u=1.5\,\mathrm{s}$.
We therefore additionally compare with $G_{i,t}(\tau_u)$
to isolate the benefit of the learned branch from the change
in geometric operating point.
The evaluated rule does not use ensemble-dispersion abstention,
severity damping, or the fixed 0.75 escalation threshold.
~~~

If keeping Algorithm 1 instead, do not paste that final sentence. Route every experiment through the full severity policy, explicitly define speech thresholds, and prove protection after downstream gating. Add a deterministic unavailable/NaN-head fallback and tests for every branch and boundary.

### R9 — Honest urgent-preservation proposition

**Replace:**

> “A mispredicting head therefore degrades the system to a constant-velocity baseline, never to silence.”

**With:**

~~~latex
\noindent\textbf{Proposition (urgent-decision preservation).}
For the Boolean fusion
$A_{i,t}=G_{i,t}(\tau_u)\lor H_{i,t}$,
we have $A_{i,t}\ge G_{i,t}(\tau_u)$ for every input
and every learned score.
The claim follows directly from Boolean disjunction.
It does not imply
$A_{i,t}\ge G_{i,t}(\tau_b)$ when $\tau_b>\tau_u$.

This invariant concerns candidate alert decisions only.
It assumes that geometric estimates are available and does not
establish accurate perception, timely delivery after arbitration,
successful human avoidance, or absence of collisions.
~~~

This proof is elementary and cannot, by itself, carry a novelty claim. A new research contribution must lie in a nontrivial validated risk construction, problem formulation, data, mechanism, or empirical finding.

### R10 — Correct finite-sample conformal statement

**Replace the current guarantee paragraph**, after adopting the appropriate split/unit:

~~~latex
Fix $\alpha\in(0,1)$ and the scoring function using data independent of conformal
calibration. Let $S_1,\ldots,S_n,S_{\mathrm{new}}\in[0,1]$
be exchangeable scores of positive calibration episodes and a new
positive episode from the same target population.
Write $S_{(1)}\le\cdots\le S_{(n)}$ and
$k=\lfloor\alpha(n+1)\rfloor$.
Define
\begin{equation}
\theta_\alpha=
\begin{cases}
0, & k=0,\\
S_{(k)}, & 1\le k\le n .
\end{cases}
\end{equation}
With an alert on scores at least $\theta_\alpha$,
the exchangeable-rank argument gives
\begin{equation}
\Pr(S_{\mathrm{new}}<\theta_\alpha)
\le \frac{k}{n+1}\le\alpha .
\end{equation}
The probability is marginal over calibration and the new episode;
ties are conservative under the strict miss event.
It is not a deterministic bound on a realized future sequence
or a confidence-$1-\delta$ population-risk statement.
~~~

**To target timely warning rather than window classification**, define:

~~~latex
For a positive episode $i$ with breach time $b_i$ and required
lead $L$, let $\mathcal T_i(L)$ contain the observed decision
timestamps no later than $b_i-L$.
We restrict this guarantee to episodes with
$\mathcal T_i(L)\ne\varnothing$ and define
\begin{equation}
S_i^{(L)}=\max_{t\in\mathcal T_i(L)} q_i(t).
\end{equation}
Applying the rank construction to one such score per independent
episode controls the marginal head-only failure to issue an alert
by this deadline.
A Boolean OR with an urgent geometric branch cannot remove
an alert already produced by that head decision rule.
~~~

**Critical qualifications:** This targets “any qualifying alert before the deadline” and still requires a sensible eligibility interval and alert-to-hazard matching definition. If a guaranteed event must occur only in a bounded pre-breach window, define that window explicitly. Episodes without any pre-deadline observation are failures of system coverage and must be reported separately; do not silently discard them from headline system recall. A downstream stateful policy can invalidate the OR implication if it cancels or delays alerts. Adaptive per-user recalibration needs fresh, appropriately sampled labels and an explicit sequential-validity argument; it does not automatically preserve exchangeability.

If high-probability population risk is truly needed, use a separate, correct risk-control method with confidence parameter delta and a simultaneous selection argument. Do not relabel the marginal rank statement “95% safe.”

### R11 — Independent calibration reporting and corrected captions

**Replace:**

> “At every α ... the empirical miss rate on held-out windows stays at or below the budget...”

**With, before new independent results exist:**

~~~latex
The present operating curve selects an empirical quantile and
measures its in-sample positive-window miss fraction on the same
examples. This diagnostic checks the quantile implementation;
it is not independent validation of future coverage.
We therefore do not interpret this curve as deployment risk control.
~~~

**After correcting the experiment, use:**

~~~latex
For each prespecified $\alpha$, we select $\theta_\alpha$ on
the conformal calibration episodes and evaluate this unchanged
threshold on independent test episodes.
Figure~\ref{fig:calibration} reports test timely-miss fractions,
test nuisance-alert rates, and episode-level uncertainty intervals.
Observed finite-test fractions need not lie below $\alpha$
in every run, even when a marginal guarantee is valid.
~~~

**Replace Figure 2's current reliability caption** if retaining its existing seed-0 data:

~~~latex
\caption{Left: reliability on 4,480 reporting windows, using
ten equal-mass bins. The reporting-split ECE is 0.0184.
The values 0.0156 and 0.0065 describe raw and scaled ECE
on the separate temperature-fitting data and are not the ECE
of the plotted reporting examples.
Right: an in-sample quantile diagnostic, not an independent
test of conformal coverage.}
~~~

For the revised final paper, show independent raw/scaled reporting ECE computed on the same test examples and remove the legacy fit numbers from the test panel.

### R12 — Metrics and count rewrite

**Replace the current metric paragraph** with:

~~~latex
Let $b_i$ be the first sampled breach time of positive episode $i$.
Let $a_i$ be the first eligible, correctly matched alert time,
with $a_i=+\infty$ if none occurs.
For required lead $L\ge0$, define
\begin{equation}
R_L=\frac1{N_+}\sum_{i:y_i=1}\mathbf1[a_i\le b_i-L].
\end{equation}
We report $R_0$, $R_{1.0}$, and $R_{1.5}$ separately.
An alert with lead in $[0,1)$ contributes to $R_0$ but not
to $R_{1.0}$; an alert after breach is a miss for all three.
Lead-time quantiles are conditional on matched pre-contact
alerts, with that denominator reported.
The current track-level experiment does not evaluate alert direction.
~~~

**Replace Table 4's count sentence now:**

~~~latex
Each seed uses 266 independently generated evaluation clips.
The hazard/safe counts are 73/193, 70/196, and 79/187
for seeds 0, 1, and 2, respectively, totaling 222 hazards
and 576 safe clips.
~~~

For future experiments use one common locked evaluation set for all training seeds. Say whether a number is mean of per-seed rates, pooled episode rate, or rate from a single seed. The mean of per-seed medians is not a pooled median.

If using sample SD, the existing reports give:

| Policy | Recall | Mean median lead (s) | Mean p10 (s) | Synthetic alerted-safe clips/km | Late clips |
|---|---:|---:|---:|---:|---:|
| Geometric 2 s | 1.000±0.000 | 1.883±0.029 | 1.300±0.100 | 28.704±1.963 | 3.0±1.0 |
| Head only | 0.995±0.008 | 1.767±0.058 | 1.367±0.115 | 14.138±1.700 | 3.0±2.0 |
| Evaluated OR fusion | 1.000±0.000 | 1.767±0.058 | 1.500±0.000 | 21.635±2.597 | 0.0±0.0 |
| Privileged-future reference | 1.000±0.000 | 1.900±0.000 | 1.567±0.058 | 0 | 0 |

These are **legacy summaries**, not results of a repaired protocol. They should not be used to imply Algorithm 1 was evaluated or to conceal changing evaluation sets.

### R13 — Honest real-replay paragraph

**Replace:**

> “confirm the head's false-alarm suppression on real traffic”

**With:**

~~~latex
On the supplied Argoverse-derived histories, the head-only
rule alerts on 595 histories versus 1,261 for the geometric
baseline, whereas the evaluated fused rule alerts on 1,300.
These histories lack the labels needed to classify suppressed
alerts as correct or incorrect.
The result therefore describes alert propensity, not
false-alarm reduction, warning recall, or pedestrian safety.
The current replay additionally requires a causal-coordinate
and velocity-estimation correction before online interpretation.
~~~

Do not preserve the last sentence as a permanent “limitation” while continuing to claim causal replay. Correct the code and rerun, then describe the corrected estimator and new numbers.

### R14 — Limitations, societal impact, and availability

**Replace the current limitations with:**

~~~latex
\paragraph{Limitations.}
The experiments evaluate a track-level warning policy under
specified simulated dynamics and measurement corruption.
They do not establish robustness to missed detections,
metric-depth bias, occlusion, identity switches, body motion,
sensor faults, or unmodeled agent behavior.
An urgent geometric fallback preserves only decisions produced
by that geometric estimator; it does not certify collision
avoidance or protection against upstream error.
No blind or low-vision participant deployment was performed.
Driving-trajectory replay is not a substitute for labeled
egocentric pedestrian evaluation, and unlabeled alert reduction
does not determine warning quality.
Head-level compute counts exclude perception, notification,
and human response. End-to-end latency and thermal behavior
remain unmeasured.
~~~

**Replace the false “no human-subject data ... used” statement with:**

~~~latex
No new participants were recruited and no new human data were
collected for the experiments reported here.
We performed secondary analysis of public KITTI annotations
and an Argoverse-derived trajectory release, subject to their
respective access terms and preprocessing limitations.
Any future participant collection requires applicable
institutional review, informed consent, supervised safety
procedures, and a documented bystander-privacy protocol.
~~~

**Add a specific impact paragraph:**

~~~latex
Incorrect or delayed alerts can create over-reliance, confusion,
and alarm fatigue. Performance may differ across mobility
patterns, walking aids, hearing abilities, environments,
and sensor placements; these differences have not been measured.
Camera and location logging can expose bystanders and routes.
The proposed study therefore requires data minimization,
controlled access, validated redaction, and participant control
over emergency-contact and location sharing.
This research prototype is not a validated replacement for
a cane, guide dog, or professional orientation-and-mobility advice.
~~~

**Availability text must be conditional on actual packaging:**

~~~latex
The anonymous artifact includes the complete decision-layer
implementation, environment specification, seeded simulator,
split manifests, and scripts for the reported tables.
The artifact README identifies each experiment's inputs,
output files, software versions, and hardware.
External datasets remain subject to their original terms.
~~~

Use this only after a clean-directory reproduction passes. Until then, write “The supplied snapshot contains weights and result files but is not yet a standalone reproduction package.” Retain a factual AI-assistance statement if appropriate, but remove “Per CVF policy” unless the exact target-year requirement is verified.

### R15 — Fall and demo claims

**Replace the zero-weekly-alert projection with:**

~~~latex
On the specified simulated episodes, the detector fired on
240/240 fall templates and 0/300 nuisance templates.
These finite-sample results do not establish zero deployment
false alerts. Under an independent identical episode model,
the one-sided 95\% upper bound on nuisance firing probability
is $1-0.05^{1/300}\approx0.00994$.
The model and its event-frequency extrapolation have not been
validated on real falls or activities of daily living.
~~~

**Replace Figure 6's identity claim with:**

~~~latex
\caption{Illustrative browser replay using a three-member,
four-decimal export of the five-member research ensemble.
Its predictions and dispersion need not equal those of the
evaluated model; this interface is not a validation experiment.}
~~~

Alternatively export all five members and verify probability, threshold-branch, first-alert-time, and dispersion equivalence on a frozen test corpus. Choose numerical tolerances before testing, report all branch mismatches near thresholds, and recalibrate if numerical/model changes are material. Merely matching the stored temperature is insufficient.

## 4.3 Exact baseline and ablation blueprints

Every row below must use the same test clips, simulator seeds/noise realizations, frame eligibility, geometric radius, and alert matching. Thresholds are selected only with the designated validation/calibration data. A dash means not applicable; “pending” means not measured, never zero.

### T1 — Operating-point and baseline fairness

| Row | Predictor / decision | History | Geometric trigger | Selection rule |
|---|---|---:|---|---|
| G1 | CV TTC only | current state | 1.0 s | fixed |
| G2 | CV TTC only | current state | 1.5 s | fixed; essential matched fallback |
| G3 | CV TTC only | current state | 2.0 s | original baseline |
| G4 | CV TTC only | current state | 2.5 and 3.0 s | prespecified sweep |
| G5 | CV TTC + causal smoothing | 8 samples | validation-selected | same tuning budget as learned policy |
| K1 | Constant acceleration | 8 samples | horizon entry | validation-selected |
| K2 | Constant turn-rate / velocity | 8 samples | horizon entry | validation-selected |
| L1 | Logistic regression | 1 sample | calibrated score | same deadline objective |
| L2 | Logistic regression | 8 samples | calibrated score | essential temporal linear baseline |
| L3 | Single 64–32 MLP | 8 samples | calibrated score | same splits |
| L4 | Five-member MLP | 8 samples | calibrated score | head only |
| F1 | Urgent OR head | 8 samples | 1.5 s OR score | reproduced method |
| F2 | Warning OR head | 8 samples | 2.0 s OR score | tests full baseline alert preservation |
| F3 | Geometric AND head | 8 samples | fixed matched geometry | intentionally removes safety floor; diagnostic |
| F4 | Printed Algorithm 1 + complete alert policy | 8 samples | explicit | only after shared-policy implementation |
| P1 | Learned trajectory forecast + simple alert | matched observation duration | entry probability | only if training/data/compute parity documented |
| O1 | Privileged true future | oracle | predefined deadline | reference, not a deployable competitor |

Columns for every result row:

**Policy; training seed count; independent test groups; positive/negative counts; \(R_0\); \(R_{1.0}\); \(R_{1.5}\); miss/late counts; median/p10/min lead with denominator; alerted-safe clips/100; actual alert events/min; synthetic FA/km only if its denominator is appropriate; head latency p50/p95/p99; 95% paired cluster CI of primary differences.**

Choose a primary endpoint in advance: for example, nuisance cost subject to a prespecified lower confidence bound on \(R_{1.0}\), or the full nuisance-versus-timely-miss curve. Do not select a different favorable metric for each competitor. If no method meets the safety target, report that outcome.

### T2 — Disentangle the printed policy's components

| Row | Urgent protection | Learned escalation | Non-urgent damping | Spread gate | q+2d heuristic | Purpose |
|---|---|---|---|---|---|---|
| A0 | yes | no | no | no | no | matched geometry control |
| A1 | yes | yes | no | no | no | escalation contribution |
| A2 | yes | yes | yes | no | no; q≤threshold | naive suppression |
| A3 | yes | yes | yes | yes | no | dispersion gate |
| A4 | yes | yes | yes | no | yes | heuristic separately |
| A5 | yes | yes | yes | yes | yes | full printed design |
| A6 | no | yes | yes | yes | yes | loss of urgent floor, simulation-only diagnostic |
| A7 | yes | unavailable / NaN head | no | fallback | no | degraded mode |
| A8 | yes | adversarially wrong head | worst-case | controlled | controlled | preservation property |

Use T1's outcome columns and add counts of calls to each branch, thresholds actually used, delivered-versus-candidate alerts, and per-episode policy traces. Do not claim heuristic safety from the existence of a branch.

### T3 — Model, features, uncertainty, and calibration

| Factor | Required settings | Keep fixed |
|---|---|---|
| History | W=1,2,4,8,16; plus shuffled-order control | labels, evaluation clips, training budget |
| Width/capacity | logistic, 32–16, 64–32, 128–64 | same splits, seeds, tuning |
| Ensemble size | M=1,3,5 | total training cost reported; recalibrate each |
| Bootstrap | none; window bootstrap; episode bootstrap | initialization seeds and endpoint |
| Features | full; no class; no width; no quality; no inverse TTC/CPA; history shuffled | retrain and recalibrate each |
| Loss | BCE; weighted BCE; focal with gamma=2 | calibration procedure |
| Temperature | none; independently fitted | identical classifier |
| Threshold | fixed; validation-tuned; conformal rank | exact optimization target and split |
| Dispersion | absent; raw d; transformed-member d | documented output units |
| Sampling prior | alternate nuisance prevalences | report prior shift, not just AUROC |

Columns: parameters, train wall time, AUROC/AP, test NLL/Brier/ECE, positive-event coverage with intervals, and final timely-alert/nuisance metrics. AUROC improvements alone cannot justify a module intended to change threshold decisions.

### T4 — Hyperparameter surfaces

Prespecify alpha in {0.02,0.05,0.10,0.15,0.20}; urgent threshold in {1.0,1.5,2.0} s; spread cutoff in {0.05,0.10,0.18,0.30}; dispersion multiplier in {0,1,2,3}; suppression factor in {0,0.35,0.7,1}; and geometry/score mixture in {0,0.25,0.5,0.75,1}. These are proposed search grids, not experiments that have already run.

Avoid a giant Cartesian test-set search. Choose the primary policy on validation, then show limited preregistered one/two-factor test surfaces without retuning to test outcomes. Plot nuisance rate with hatched cells for missed timely-recall targets. Record calibrated thresholds for each changed score function; changing ensemble or features without recalibration is unfair.

### T5 — Robustness and transfer

| Axis | Proposed settings / checks | Required measurements |
|---|---|---|
| Dynamics | leave one family out; new acceleration/turn distributions; late yield; no yield | timely recall, conditional nuisance |
| Range scale | multiplicative bias −20%,−10%,0,+10%,+20% | bias sensitivity, calibration breakdown |
| Noise | 0.5×,1×,2×,4× original; correlated drift | event-level coverage, false urgent rate |
| Occlusion / track dropout | 0,0.2,0.5,1.0 s; late track birth | observation coverage and total misses |
| Tracking | ID changes, duplicates, missed association | repeats, branch errors |
| Ego motion | speed changes, turns, pitch error | relative-state error and timely alerts |
| Multi-agent | 1,5,10,20 simultaneous tracks | arbitration losses, speech occupancy |
| Real trajectories | official data with valid timestamps/futures; frozen transformations | causal alerting and labeled event outcomes |
| Real vision, if claimed | matched RGB sequence, actual detector/depth/tracker | range/velocity errors and downstream outcome |
| Fall supplement | leave-template-out; orientation/site changes; noise; quiet sit/standing immobility | sensitivity/specificity with event intervals |

Do not reinterpret synthetic corruption as a test of actual rain/night/glass perception. Only real imagery evaluated by the actual perception stack can support that assertion.

### T6 — Efficiency table, exact scope

| Module / policy | Params | MACs/decision | Precision | Hardware/threads | Tracks/batch | p50/p95/p99 ms | Peak RAM | Peak VRAM | Deadline miss % |
|---|---:|---:|---|---|---:|---|---:|---:|---:|
| Feature extraction + geometry | — | report measured implementation scope | pending | exact CPU | 1/10/50 | pending | pending | — | pending |
| One 64–32 head | 9,345 | 9,248 dense MACs | report | exact CPU | 1/10/50 | pending | pending | — | pending |
| Five-head ensemble | 46,725 | 46,240 dense MACs | report | exact CPU | 1/10/50 | pending | pending | — | pending |
| Calibration + policy | — | report separately | report | exact CPU | 1/10/50 | pending | pending | — | pending |
| Full decision layer | subtotal | subtotal + geometry | report | exact CPU | 1/10/50 | pending | pending | — | pending |
| Detection | exact checkpoint | pending | report | exact GPU/device | input resolution | pending | pending | pending | pending |
| Depth | exact checkpoint | pending | report | exact GPU/device | input resolution | pending | pending | pending | pending |
| Segmentation, amortized and worst case | exact checkpoint | pending | report | exact GPU/device | masks/frame | pending | pending | pending | pending |
| End-to-end sensor→notification | full | full | report | exact device | scene track count | pending | pending | pending | pending |

One MAC is conventionally counted as two FLOPs in some reports; explicitly state the convention. The dense-MAC counts above exclude nonlinearities, feature construction, calibration, and notifications. Report training wall time, epochs actually executed, peak process memory, software/BLAS versions, warm-up, measurement repetitions, load/thermals, and synchronization boundaries. Do not fill “0” for unmeasured GPU memory.

### LaTeX results-table skeleton

~~~latex
\begin{table*}[t]
\centering
\small
\begin{tabular}{lccccccc}
\toprule
Policy & $R_0$ & $R_{1.0}$ & $R_{1.5}$
& Miss/late & Lead p10
& Alerted safe/100 & p99 latency \\
\midrule
CV TTC, $1.5\,\mathrm{s}$ & pending & pending & pending
& pending & pending & pending & pending \\
CV TTC, $2.0\,\mathrm{s}$ & pending & pending & pending
& pending & pending & pending & pending \\
Temporal logistic & pending & pending & pending
& pending & pending & pending & pending \\
MLP head & pending & pending & pending
& pending & pending & pending & pending \\
Urgent OR head & pending & pending & pending
& pending & pending & pending & pending \\
Full severity policy & pending & pending & pending
& pending & pending & pending & pending \\
\bottomrule
\end{tabular}
\caption{Template for a common-test-set comparison.
All operating points are selected without test labels.
Report independent episode counts and paired cluster uncertainty
in the text or a companion table.
Pending cells must be replaced only by measured results.}
\label{tab:matched_policies}
\end{table*}
~~~

## 4.4 Figure redesign specifications

### Figure 1 — Three-panel teaser with actual branch evidence

- Make a full-width page-1 figure. Panel A: yielding pedestrian and non-yielding crosser with the same initial geometry, true future trajectories, estimated trajectories, wearer envelope, observation cutoff, and breach time if any. Mark whether imagery is real or synthetic; do not create photorealistic pictures that look like new field evidence.
- Panel B: aligned time axes for TTC, q, threshold, and baseline/head/fused alerts. Use the same episode and noise realization for all policies. Show one safely removed nuisance warning and one timely geometric override.
- Panel C: nuisance versus timely-miss trade-off across matched geometric and learned operating points, with confidence intervals. Include an observed failure or explicitly mark the evidence as simulation-only.
- Use colors plus shapes/line styles. Define orange=head, blue=geometry, red=miss/deadline, black=ground truth; keep this convention throughout.
- Caption must name the event definition, actual lead times, source episode IDs, model/policy hash, and whether the example is illustrative or from the fixed test set.

### Figure 2 — Self-contained method diagram

- Left grey context: RGB camera, IMU, and unmeasured perception path. Dashed outline and “not evaluated here” if no pixel experiment is added. Do not imply frozen model accuracy or latency was measured.
- Center solid path: timestamped track state N×4; features N×W×14; flatten to N×112; five independently trained 112→64→32→1 MLPs; mean aggregation; temperature; threshold.
- Show separate model-selection, temperature-fit, and conformal data flows as offline dashed arrows, distinct from online features. Put the focal-loss attachment at raw member predictions and labels, not at the fusion output.
- Draw an explicit track-feature input arrow into the MLP. The current head is visually disconnected from its input.
- Right: exact chosen fusion rule with its Boolean or severity output type; final policy; delivery. Show urgent bypass through any stateful gate if that is actually implemented and tested.
- Mark trainable components, fitted scalar temperature, fitted quantile, deterministic geometry, frozen pretrained models, and unevaluated modules with separate symbols, not just color.
- State no latency in the diagram without labeling it “measured” with platform or “target.” Use a full-width layout with legible final-size typography.

### Figure 3 — Calibration that can fail honestly

- Panel A: raw and calibrated reliability on the **same independent test clips**, with bin counts and intervals. ECE labels must be recomputed on the plotted data.
- Panel B: alpha versus test timely-miss fraction, fixed calibration thresholds, episode-cluster intervals. Do not force every point below the diagonal.
- Panel C: coverage under family shift and depth-scale bias, showing the exchangeability boundary rather than implying universal validity.

### Figure 4 — Failure grid

Use rows for (1) yielder, (2) late crosser, (3) cut-in scooter, (4) persistent depth bias, (5) track dropout/ID switch, (6) multiple simultaneous hazards, and (7) confidently wrong ensemble. Use columns: input/track plot; ground truth; matched geometric baseline; head-only; proposed fused output. Add enlarged crops only for actual image evidence. If the study remains track-only, use ground-plane zooms instead.

For every row show q, dispersion, estimated TTC, true breach/deadline, branch taken, and delivered alert time. Include failure causes and what the fallback could not protect. There is no meaningful attention map for this MLP; use feature/time interventions or branch traces instead of decorative t-SNE.

### Fall and browser figures

Move to supplementary system context. For the IMU figure, show acceleration magnitude, orientation change, stillness statistic, phase boundaries, and confirmation time—not acceleration alone for a conjunctive rule. Make the browser screenshot large enough to read if retained, and label it an interface demonstration with the correct model export scope.

## 4.5 Pre-emptive defense under limited compute or time

**What can be done on CPU now:** repair causal adapters, preserve split groups, re-evaluate attached weights, train temporal logistic/MLP controls, run TTC/acceleration baselines, compute confidence intervals, test shared-policy branches, fix plotting, and package a clean artifact. The existing setup already supports these computations. Lack of GPUs does not excuse a policy mismatch or same-sample coverage evaluation.

**What cannot be defended without new evidence:** real-world safety, collision avoidance, a 30 ms full perception loop, superiority to modern vision systems, clinically meaningful fall reliability, or a field effect on adoption.

If no labeled real experiment can be completed, remove those claims and frame the work as a controlled simulator study of a specified decision rule. Remove perception/VLM/fall modules from the novelty argument. State that the geometric fallback's invariant is conditional and simple. Present the weakest operating points and the AV2 fused increase with the same prominence as favorable numbers.

This rescoping makes the work more accurate; it does **not** force acceptance. A track-only study with a trivial OR invariant may remain below CVPR's novelty/evidence bar. A serious submission route is either (a) a nontrivial temporally valid risk-control result with convincing matched experiments, or (b) an ethically collected/curated, well-labeled egocentric warning benchmark with robust baselines, or (c) a narrower workshop/system demonstration whose claims match its evidence. A safety-critical participant study should not be rushed to satisfy a conference date.

## 4.6 Issue-to-fix closure ledger

| Finding | Required closure | Evidence to retain |
|---|---|---|
| A1 length | cut roadmap/fall/demo prose; reflow | page 9 contains no main-paper text |
| A2 anonymity | clean review-only package; relative paths | PDF/source/archive identity scan |
| A3 variants/ID | one compiled artifact and actual ID | release hash/manifest |
| A4 readability | redesign figures/tables at final size | printed-size rendering |
| A5 ethics wording | R14 and actual data provenance | dataset/institutional determination records |
| A6 privacy tool | fail-closed redaction, random IDs | failure-path tests and release audit |
| A7 assets | asset/license/checkpoint inventory | terms/versions/hashes |
| A8 reproduction | full library and locked environment | successful clean-directory run |
| B1 claims | R1/R2/R9/R14 | final claim-to-result ledger |
| B2 teaser | redesigned Figures 1/2 | matched episode visual evidence |
| B3 novelty | runtime-assurance comparison + recent search | verified bibliography and mechanism matrix |
| B4 geometry/labels | R3, event discretization tests | unit/event-definition tests |
| B5 TTC | R4 | inside/stationary/tangent/receding tests |
| B6 depth | evaluate scale/offset or remove contribution | actual range errors or explicit scope cut |
| B7 formalism | R6/R7 + feature appendix | shapes and saved-weight compatibility |
| B8 conformal | R10 + independent clip splits | split manifests and theorem assumptions |
| B9 plot leakage | R11 + independent test plot | fixed threshold and plotted-data hashes |
| B10 threshold missing | R8 or actual full-policy rerun | branch-level implementation trace |
| B11 policy mismatch | T1/T2 and one shared entry point | equivalence tests and fresh result ledger |
| B12 false UCB | R7 and T3/T5 | correct dispersion labels and shift tests |
| B13 safety overreach | R9, final output tests | invariant scope and arbitration stress tests |
| B14 simulator transfer | T3/T5 or R14 scope cut | held-out mechanisms and failure data |
| B15 metrics | R12 | event matching and deadline-specific confusion counts |
| B16 statistics | corrected counts/common test/clusters | raw paired event files and CI procedure |
| B17 replay leakage | R5 and all replay reruns | future-prefix-invariance tests |
| B18 unlabeled AV2 | R13; labeled experiment if claiming FA | alert-propensity labels or true outcomes |
| B19 fairness/efficiency | T1/T6 | common protocol and timing logs |
| B20 ablations/failures | T2–T5 and failure grid | full per-cell artifacts |
| B21 fall | R15 and supplemental placement | counts/uncertainty, no weekly-zero claim |
| B22 demo/oracle/conclusion | R15; parity tests; narrow conclusion | export comparison and justified oracle scope |
| Rebuttal Q1 | B10/B11 closures | shared implementation and matched fallback |
| Rebuttal Q2 | B8/B9/B13 closures | correct unit/target/splits/proposition |
| Rebuttal Q3 | B17/B18 closures | causal rerun and labels |
| Rebuttal Q4 | B3/B19/B20 closures | novelty comparison and isolating baselines |
| Rebuttal Q5 | A8/B16/B19 closures | raw outcomes, corrected counts, measured compute |

# PHASE 5 — Line-by-line polish and LaTeX micro-edits

These are exact textual fixes, not substitutes for experiments. “After rerun” means regenerate from the final policy; do not copy an obsolete result into polished prose.

## 5.1 Main source micro-edit ledger

| Source location | Change [X] | To [Y] / exact action |
|---|---|---|
| L15 | paperID ***** | actual assigned submission identifier; do not invent one |
| L19–20 | redefining \eg and \ie | delete both redefinitions and use the official template macros |
| L22 title | “Escalate, Never Suppress” | R1's title qualifying urgent-decision preservation |
| L31 abstract | “an 0.8 s window” | “an eight-sample window” |
| L31 | “holds an absolute veto over urgent alerts” | “preserves urgent geometric alert decisions” |
| L31 | “warnings can only be made earlier by making them more frequent” | “earlier thresholds can increase unnecessary alerts” |
| L31 | “switched off within weeks” | remove or supply direct longitudinal evidence |
| L31/L52 | “degrades ... to a reactive baseline rather than to silence” | “the learned branch cannot remove decisions from the urgent geometric gate” |
| L31 | “miss rate obeys ... distribution-free guarantee” | R10's precise marginal statement, after its assumptions are established |
| L31 | “73 hazard clips in every run” | “73, 70, and 79 hazard clips for the three evaluation seeds” |
| L31 | p10 “head alone never reaches” | qualify as mean across the three reports; head-only p10 reaches 1.5 s on seed 1 |
| L31 | “false-alarm suppression on real traffic” | “lower head-only alert frequency on unlabeled replay” |
| L31 | “we release ... with the field study” | “we release the evaluation artifact; a field study has not been performed,” once artifact completion is verified |
| L37 | “has roughly two seconds” | cite an operational/behavioral basis or write “we evaluate a two-second horizon” |
| L37 | “The gap is not perception quality” | R2's separation of perception and decision timing |
| L39 | “A missed hazard is an injury” | “A missed hazard may leave a wearer without a useful warning” |
| L39 | “gets switched off” | “may contribute to non-use,” with adoption evidence |
| L41 | CV “cannot represent” deceleration | “constant velocity does not explicitly model acceleration” |
| L43 | “shows the whole system on one page” | “summarizes the proposed pipeline,” with evaluated scope marked |
| L47 | architecture at 0.8 linewidth | a legible full-width method figure |
| L48 | “owns every safety decision” | “provides the geometric branch of the evaluated warning rule” |
| L52 | escalation “freely” | state the actual threshold and any disagreement prerequisite |
| L54 | “To keep the head honest” | “We assess calibration on independent reporting data,” after repair |
| L54 | “corrects the overconfidence” | “fits a scalar temperature”; improvement must be measured |
| L56 | fixed hazard/safe counts for every seed | R12's three actual count pairs |
| L56/L391 | “24.7%” | “24.6%” using unrounded supplied means; regenerate after rerun |
| L60–63 | “(\eg~\ref{sec:...})” | “(Sec.~\ref{sec:...})”; “e.g. 4.4” is not a section reference |
| L61 | “at or below the budget at every α tested” | independent test estimates with uncertainty, not a self-fitted quantile property |
| L62 | “counts late alerts as misses” | “reports detection recall and deadline-specific timely recall separately” |
| L63 | fall as a technical contribution | move to supplementary implementation context |
| L66 | “safety argument does not depend on field performance” | “the conditional urgent-decision invariant does not establish field safety” |
| L79–81 | repeated “depth / aware / temporal” header | remove the duplicate header row |
| L88/L91 | unqualified Ours miss-rate guarantee | name the unit, endpoint, assumptions, and marginal interpretation |
| L96 | forecasts “run at rates well below” the safety loop | give a model/platform measurement or remove |
| L96 | “where it provably fails” | “where constant velocity does not model the relevant motion change” |
| L108 | “range falls below” | “planar center distance is at most the combined operational radius” |
| L108 | rates “in metres and seconds” | positions “in metres,” velocities “in metres per second” |
| L114 | undefined position dimension/norm/empty set | R3's explicit planar Euclidean definition |
| L118 | “correctly directed alert” | “eligible matched alert” until direction is actually scored |
| L132 | hard-coded “Eq.~(1)” | “Eq.~\eqref{eq:ttb}” with the correct maintained label |
| L145 | “p-hat exceeds ensemble agreement requirements” | “ensemble dispersion is below the agreement threshold” |
| L145 | no threshold sweep “allowed” to reduce recall | state the implemented invariant, not a prohibition on unfavorable results |
| L154 | “within a 30 ms design tick” | “with an unvalidated 30 ms compute target in a 100 ms scheduling period” |
| L158 | “3D ... in the ground plane” | “planar constant-velocity filters with four state variables” |
| L158 | “dropping y halves the state” | “reduces a six-dimensional position–velocity state to four dimensions” |
| L163–165 | equality-only TTC | R4's first-entry equation with initial-inside handling |
| L171 | “0.8 s ... 112 numbers” | eight samples, 0.7 s sample span, flatten order and W×D shape |
| L171 | dataset-fit normalizers are inherently skewed | “normalization constants are fixed and stored”; fitted train-only normalizers are not inherently invalid |
| L173 | “Window length is not a free parameter” | “We select history length on validation data and report sensitivity,” after that experiment |
| L175 | “two-layer MLP” | “MLP with two hidden layers and one output layer” |
| L175 | “9.3k multiply-adds” | “9,248 dense MACs and 9,345 parameters per member,” with exclusions |
| L175 | bootstrap equated to data uncertainty | specify bootstrap unit; do not assert coverage |
| L175 | bigger model buys only “a fifth decimal place” | describe measured change and report downstream effects; provide the claimed probe artifact |
| L181 | “cannot overfit the small calibration set” | “has one fitted parameter but still requires independent calibration assessment” |
| L187 | exchangeability “holds by construction” | episode-level assumption under the stated simulator distribution |
| L187 | ambiguous “floor ... /n quantile” | explicit one-indexed order statistic, R10 |
| L187 | bound on “fraction of future hazards” | marginal probability for a new exchangeable positive episode |
| L199 caption | alarm rate falls as α “tightens from 0.20 to 0.02” | alarm rate falls as α increases from 0.02 to 0.20 |
| L199 | fit ECE displayed as reporting ECE | plotted reporting ECE is 0.0184; compute raw/scaled test ECE on the same examples |
| L215 | mean and spread “temperature-scaled” | actual ordering and raw/calibrated spread definition, R7 |
| L222/L232 | “pessimistic UCB” | “ensemble dispersion heuristic,” unless coverage is established |
| L232 | damped conflict “still surfaces” | damping can silence a downstream threshold; prove the actual protected event |
| L234 | selected alert “is the right one” | scheduler correctness is a separate evaluated property |
| L240 | three-way fall conjunction | “impact AND stillness AND (free-fall OR posture change)” |
| L240 | “adding nothing” to the fast-path budget | “scheduled separately; shared-resource overhead is unmeasured” |
| L245 | VLM “at 1–2 tok/s ... can never” | language is excluded from the safety path; do not generalize one speed across models/devices |
| L247–272 | twelve-feature roadmap | remove from main paper |
| L280 | “appearance realism is a distraction” | the study isolates track noise and does not assess visual-domain shift |
| L281 | different seeds prevent overlap “even by coincidence” | store episode IDs/parameters and verify disjointness |
| L283 | “One honesty note” | “Normalization,” followed by the exact exposure denominator |
| L286 | focal α=0.6 and conformal α=0.1 | focal β=0.6 and risk α=0.1 |
| L286 | “patience 15” | specify validation checks versus epochs; workspace checks roughly every three epochs |
| L286 | only nondeterminism is reduction order | record numerical environment and tested reproducibility tolerance |
| L286 | every entry reproduced “to the last digit” | actual tested tolerance on the named environment |
| L295 | scriptsize comparison | readable full-width table or fewer columns |
| L307 | same tensor proves fairness | document histories, tuning, splits, deadlines, and policy parity |
| L311 | head “genuinely understands” | achieves lower nuisance-alert frequency on the tested distribution |
| L311 | “219 hazard clips” | “222 hazard clips” |
| L311 | “shipping rule” | “evaluated OR policy,” until deployment equivalence is established |
| L313 | abstract numbers are “single-seed ... seed-0” | distinguish three-seed abstract means from seed-0 figures |
| L313 | remaining gap “lives in perception noise” | experiment does not identify the source of the reference-policy gap |
| L318 | hazard histogram's early mass comes from false alarms | safe-clip false alarms are a separate population; describe earlier hazard warnings |
| L325 | “keeping 9.0” | “a 9.0/km reduction on seed 0,” not the three-seed effect |
| L334 | wearer “should choose with a dial” | risk parameter requires validated selection and communication |
| L339 | zero weekly false alerts | finite-sample counts and uncertainty, R15 |
| L339 | caregiver latency is “acceptable” | acceptability has not been evaluated |
| L341 | stillness “carries” specificity | demonstrate stillness-removal ablation or state a hypothesis |
| L240 “SVN” | undefined inconsistent acronym | define “signal-vector magnitude (SVM)” consistently |
| L353 | “unmodified decision stack” | actual evaluated track-level policy, or demonstrate exact shared-policy execution |
| L353 | “causal ... smoothing” | corrected timestamp-aware backward estimator after code repair |
| L355 | “0 real breaches” | no sampled breaches under retained-track envelope/eligibility definition |
| L357 | AV2 “no class labels” | selected mirror's loaded representation omits class metadata |
| L357 | “Neither corpus carries breach labels” | KITTI envelope labels are derived; selected AV2 mirror lacks non-focal future labels |
| L357 | “three times KITTI's scale” | name comparable units; 22,127 histories is not three times 644 tracklets |
| L362 | “if demo and paper disagree, one is wrong” | demo differs in member count/precision; test equivalence or label approximate |
| L366 | screenshot width 0.56 linewidth | remove or enlarge in supplement |
| L367 | “Identical weights” | “three-member rounded subset,” unless export/parity is corrected |
| L375 | required latency belongs in “a field paper” | timing is unmeasured; measure now if making deployment claims |
| L375 | lack of participants is the “strongest objection” | algorithm and statistical validity failures stand independently |
| L380 | no raw logs leave the device | distinguish intended privacy architecture from verified operational data flows |
| L383 | no human-subject data was used | no new recruitment/collection; public secondary analysis, R14 |
| L383 | pinned dependencies | include a real lock or remove the claim |
| L386 | “Per CVF policy” | factual AI-use disclosure without asserting an unverified target-year mandate |
| L391 | replays “replicate” suppression | exact head/fused counts, causal rerun, and label availability |
| L393–396 | small bibliography | retain official style; do not shrink references further |

The line numbers will shift during editing. Use the quoted strings and LaTeX labels to locate content.

## 5.2 Reference and attribution edits

1. **The AV2 entry has the wrong author list for its title.** The official av2-api README lists Benjamin Wilson, William Qi, Tanmay Agarwal, John Lambert, Jagjeet Singh, Siddhesh Khandelwal, Bowen Pan, Ratnesh Kumar, Andrew Hartnett, Jhony Kaesemodel Pontes, Deva Ramanan, Peter Carr, and James Hays. The draft begins Ming-Fang Chang and resembles the Argoverse 1 author list. Replace authors from the authoritative AV2 record and resolve venue/year against official proceedings: the retrieved upstream README itself says 2021, whereas the draft says 2023. Do not silently pick a date or retain “all references verified.”
2. **Verify the Bourke bi-axial-gyroscope citation from its primary record.** Check authors, title, year, pages, sensor modality, and the attributed discrimination claim. The key bourne2007gyro is misleading for an entry naming Bourke and year 2008, although an internal key does not itself change printed correctness. This review did not retrieve that primary record, so it does not fabricate a replacement author list.
3. **Recent model citations remain independently unverified here.** LocateAnything-3B's existence and bibliographic details were not established by a complete current literature search. A citation is also not evidence that a component was executed.
4. Protect acronym capitalization in BibTeX as appropriate: {SAM}, {TTC}, {YOLO}, {Argoverse}. Inspect the rendered references.
5. Cite assets and specify their terms/version/hash independently of generic model-family papers. No blanket license inference is justified.
6. Keep the template's \etal macro; its existing use is not a violation. Fig./Figure, Tab./Table, and Sec./Section are consistency matters unless the actual venue instructions prescribe a choice. Do not invent a desk-reject rule for personal abbreviation preferences.
7. Use “Figure” at sentence start, consistent abbreviations elsewhere, \eqref for equations, maintained labels, and nonbreaking spaces in units/cross-references. Never use “e.g.” as a section-reference prefix.

## 5.3 Captions that change scientific meaning

- **Figure 1:** state evaluated scope, show feature input and offline calibration flow, and distinguish measured timing from targets.
- **Figure 2:** fix alpha-sweep direction, ECE split labels, and the in-sample-versus-test coverage distinction.
- **Figure 3:** state the success-only lead denominator and explicitly display misses. Do not explain hazard-clip histogram mass using safe-clip nuisance alerts.
- **Figure 4:** state seed 0 and source report/hash; avoid mixing data/results.json from a different seed with seed-0 claims.
- **Figure 5:** show orientation and stillness as well as acceleration because all are decision inputs.
- **Figure 6:** label approximate three-member export, call it illustrative, and do not call a browser interface deployed wearable validation.

## 5.4 Build/package replacement

Replace verify.sh's personal path and error-masking behavior with a directory-relative, fail-fast build. A proposed skeleton is:

~~~bash
#!/usr/bin/env bash
set -euo pipefail
paper_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$paper_dir"
pdflatex -halt-on-error -interaction=nonstopmode main.tex
bibtex main
pdflatex -halt-on-error -interaction=nonstopmode main.tex
pdflatex -halt-on-error -interaction=nonstopmode main.tex
if rg -n 'Overfull|undefined' main.log; then
  echo "Inspect layout/references before release" >&2
  exit 1
fi
pdfinfo main.pdf
~~~

This is a proposed script, not a verified full submission validator. References beginning on page 9 does not prove that all content ended on page 8. Inspect the final rendered PDF; archive its hash. Do not delete source or user files merely to obtain a clean build.

Build a fresh review-only ZIP, excluding internal reviews, macOS metadata, preprint variants, stale PDFs, and nested duplicate archives. Include the complete anonymous library, tests, exact environment, and data-access/reproduction instructions. Scan figures, filenames, comments, metadata, and configuration—not only PDF author fields.

# What would materially change this review

The minimum rescue is a faithful single method, independent temporal calibration, causal replay, matched operating-point baselines, correctly defined timely metrics, and conclusions based on labeled outcomes. The stronger route toward an Oral/Highlight-level case is a nontrivial decision/risk-control result or an important benchmark with compelling evidence. Adding more pretrained modules, a longer roadmap, or a smaller p-value does not address the current rejection reasons.

The existing numerical artifacts provide a useful starting point: the simple simulated OR-policy effect is reproducible. Build from that fact instead of retaining guarantees that its experiment does not establish.

# Delivered evidence and verification limits

- evidence/audit.py and evidence/audit.json contain the report arithmetic, parameter shapes/count, direct future-frame counterexample, and workspace-assisted saved-weight simulation checks.
- evidence/urgent_geometry_control.py and its JSON contain the additional matched 1.5 s geometric control.
- LATEX_REPLACEMENTS.tex contains the proposed LaTeX fragments extracted from this manual. They are fragments to integrate with the main text, not a replacement full manuscript.
- The fragments compiled in a generic article test harness with captions placed in figure contexts. This checks syntax only. Overfull-line and unresolved-cross-reference warnings remain in the generic harness; it does not certify final CVPR layout, eight-page compliance, or a complete rebuilt submission.
- The original PDF's metadata, page-9 render, and extracted text were inspected. The current supplied style matched the official GitHub author kit. Target-year author/ethics policies could not be retrieved through the conference site, so final policy compliance remains to be checked against the actual 2027 instructions.
- No full image pipeline, hardware latency, new training campaign, raw-dataset replay, participant study, or updated scientific acceptance claim was produced by this review.

Official sources consulted or attempted: https://github.com/cvpr-org/author-kit ; https://raw.githubusercontent.com/cvpr-org/author-kit/main/cvpr.sty ; https://raw.githubusercontent.com/argoverse/av2-api/main/README.md ; https://cvpr.thecvf.com/Conferences/2027/AuthorGuidelines (blocked). The downloaded source copies are in the evidence directory. These references establish only the specific checks described above, not an exhaustive literature review.
