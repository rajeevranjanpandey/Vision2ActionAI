"""Additional review control, using a separately available workspace library.

Run with the workspace guardian venv and:
PYTHONPATH=/workspace/Vision2ActionAI/guardian python urgent_geometry_control.py

Library commit: 551aeda8fe2eb630cce638028e2c575c658c6848.
This library was absent from the uploaded ZIP. No training is performed.
"""
import json
from pathlib import Path

from guardian.bench.simeval import geometric_rule, score_arm
from guardian.config import RiskConfig
from guardian.train.simulate import generate_dataset

rows = []
for seed in range(3):
    cfg = RiskConfig()
    sequences = generate_dataset(266, cfg, seed=10000 + seed)
    # Feature 6 is 1/(TTC + 0.5 s), hence 0.5 corresponds to TTC <= 1.5 s.
    row = score_arm(
        "Geometry only TTC <= 1.5 s", sequences, geometric_rule(0.5), cfg
    ).to_dict()
    row["seed"] = seed
    rows.append(row)
output = Path(__file__).with_suffix(".json")
output.write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
