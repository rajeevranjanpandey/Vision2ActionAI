from pathlib import Path
import json, sys, importlib.util, tempfile, pickle
import numpy as np
from scipy.stats import binomtest, beta
root=Path('/workspace/cvpr-review/manuscript/AI Guardian CVPR')
sys.path.insert(0,'/workspace/Vision2ActionAI/guardian')
from guardian.config import RiskConfig
from guardian.train.simulate import generate_dataset
from guardian.bench.simeval import run_ablations,geometric_rule,fused_rule,score_arm
from guardian.risk.learned import LearnedRiskHead
from guardian.train.features import window_of,WINDOW
res={'provenance':'Attached artifacts; simulation replay additionally uses existing workspace library at commit 551aeda8fe2eb630cce638028e2c575c658c6848, absent from attachment.'}
rows=[]
for seed in range(3):
 p=root/'code'/('report.json' if seed==0 else f'report_seed{seed}.json')
 r=json.loads(p.read_text());rows.append(r)
res['reported_counts']=[{'seed':r['seed'],'hazard':r['ablations'][0]['hazard_clips'],'safe':r['ablations'][0]['safe_clips']} for r in rows]
res['means']={}
for j,name in enumerate(['baseline','head','fused','oracle']):
 res['means'][name]={key:{'mean':float(np.mean([r['ablations'][j][key] for r in rows])),'population_sd':float(np.std([r['ablations'][j][key] for r in rows])),'sample_sd':float(np.std([r['ablations'][j][key] for r in rows],ddof=1))} for key in ['recall','median_lead_time_s','p10_lead_time_s','false_alarms_per_km','late_alerts']}
res['exact_tests']={str((a,b)):binomtest(a,a+b,.5).pvalue for a,b in [(33,0),(744,78),(57,40),(43,40),(39,78)]}
res['zero_event_one_sided_95_upper']={str(n):float(1-.05**(1/n)) for n in [73,222,240,300]}
res['weekly_840_event_upper_bound_from_300_negatives']=840*(1-.05**(1/300))
a=np.load(root/'code/risk_head.npz');res['npz_keys']=a.files
res['head_shapes']={k:list(a[k].shape) for k in a.files if k.startswith('m0_')}
res['head_parameters']=int(sum(a[k].size for k in a.files if k.startswith('m0_')))
# Directly demonstrate the attachment's velocity lookahead without executing dataset pickle files.
spec=importlib.util.spec_from_file_location('attachment_av2',root/'code/av2_replay.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as td:
 trajs=np.zeros((2,21,2));trajs[1,:,0]=10-np.arange(21)*.1
 d={'obj_trajs':trajs,'obj_trajs_mask':np.ones((2,21)),'track_index_to_predict':0}
 p=Path(td)/'synthetic.pkl';p.write_bytes(pickle.dumps(d));before=mod.load_scenario(p)[0][0].states.copy()
 d['obj_trajs'][1,11,0]+=10;p.write_bytes(pickle.dumps(d));after=mod.load_scenario(p)[0][0].states.copy()
 res['causality_counterexample']={'changed_only_future_frame':11,'decision_frame':10,'velocity_before':before[10,2:].tolist(),'velocity_after':after[10,2:].tolist(),'past_positions_equal':bool(np.array_equal(before[:11,:2],after[:11,:2]))}
# Evaluate saved weights against the separately available repository, without retraining.
res['workspace_crosscheck']=[]
for seed in range(3):
 cfg=RiskConfig();seq=generate_dataset(266,cfg,seed=10000+seed)
 w=root/'code'/('risk_head.npz' if seed==0 else f'risk_head_seed{seed}.npz')
 head=LearnedRiskHead.from_npz(w)
 arms=run_ablations(seq,head,cfg)
 b=geometric_rule();f=fused_rule(head)
 suppressed=added=0
 for s in seq:
  if not np.any(np.isfinite(s.ttc_true)&(s.ttc_true<=1e-6)):
   ba=any(b(s,t) for t in range(len(s.features)));fa=any(f(s,t) for t in range(len(s.features)))
   suppressed+=ba and not fa;added+=fa and not ba
 res['workspace_crosscheck'].append({'seed':seed,'arms':[x.to_dict() for x in arms],'suppressed':suppressed,'added':added})
Path('/workspace/cvpr-review/evidence/audit.json').write_text(json.dumps(res,indent=2))
print(json.dumps({k:v for k,v in res.items() if k not in ['npz_keys','means','workspace_crosscheck']},indent=2))
print('CROSSCHECK',json.dumps(res['workspace_crosscheck'],indent=2))
