"""Verify every load-bearing number in the paper against its source file."""
import json, sys
import numpy as np

ok, fail = [], []
def check(claim, actual, expected, tol=0.051):
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        good = abs(actual - expected) <= tol * max(abs(expected), 1e-9) + 1e-9
    else:
        good = actual == expected
    (ok if good else fail).append((claim, expected, actual))

R = json.load(open("artifacts/report.json"))
R1 = json.load(open("artifacts/report_seed1.json"))
R2 = json.load(open("artifacts/report_seed2.json"))
F = json.load(open("../src/data/fall_detection.json"))
K = json.load(open("artifacts/kitti_replay.json"))
A = json.load(open("artifacts/av2_replay.json"))

def arms(rep):
    return {a["name"]: a for a in rep["ablations"]}

# --- training block
check("clips", R["train"]["clips"], 800)
check("windows", R["train"]["windows"], 36000)
check("feature dim", R["train"]["feature_dim"], 112)
check("positive rate", R["train"]["positive_rate"], 0.174)
check("val AUC", R["train"]["val_auc"], 0.9954, tol=0.001)
check("val AP", R["train"]["val_ap"], 0.9636, tol=0.001)

# --- calibration
c = R["calibration"]
check("temperature", c["temperature"], 0.349, tol=0.001)
check("threshold", c["threshold"], 0.713, tol=0.001)
check("ECE before", c["ece_before"], 0.0156, tol=0.001)
check("ECE after", c["ece_after"], 0.0065, tol=0.001)
check("Brier", c["brier_after"], 0.0146, tol=0.001)

# --- ablation means over 3 seeds
b = [arms(r)["Constant-velocity TTC (baseline)"] for r in (R, R1, R2)]
h = [arms(r)["Learned head only"] for r in (R, R1, R2)]
g = [arms(r)["Geometry + head (shipping)"] for r in (R, R1, R2)]
o = [arms(r)["Oracle (upper bound)"] for r in (R, R1, R2)]
def ms(vals, key): return float(np.mean([v[key] for v in vals])), float(np.std([v[key] for v in vals]))
for key, em, es in [("recall", 1.00, 0.00), ("median_lead_time_s", 1.88, 0.02),
                    ("p10_lead_time_s", 1.30, 0.08), ("false_alarms_per_km", 28.7, 1.6),
                    ("late_alerts", 3.0, 0.8)]:
    m, s = ms(b, key); check(f"baseline {key} mean", round(m, 2), em, tol=0.02); check(f"baseline {key} std", round(s, 2), es, tol=0.05)
for key, em, es in [("recall", 0.995, 0.007), ("median_lead_time_s", 1.77, 0.05),
                    ("p10_lead_time_s", 1.37, 0.09), ("false_alarms_per_km", 14.1, 1.4),
                    ("late_alerts", 3.0, 1.6)]:
    m, s = ms(h, key); check(f"head {key} mean", round(m, 3), em, tol=0.02); check(f"head {key} std", round(s, 2 if es < 0.005 else 3 if es < 0.05 else 2), es, tol=0.051 if es >= 0.05 else 0.006)
for key, em, es in [("recall", 1.00, 0.00), ("median_lead_time_s", 1.77, 0.05),
                    ("p10_lead_time_s", 1.50, 0.00), ("false_alarms_per_km", 21.6, 2.1),
                    ("late_alerts", 0.0, 0.0)]:
    m, s = ms(g, key); check(f"fused {key} mean", round(m, 3), em, tol=0.02); check(f"fused {key} std", round(s, 2), es, tol=0.05)
check("oracle median", ms(o, "median_lead_time_s")[0], 1.90, tol=0.01)
check("oracle p10", ms(o, "p10_lead_time_s")[0], 1.57, tol=0.02)

# --- derived paper claims
bfa = ms(b, "false_alarms_per_km")[0]; hfa = ms(h, "false_alarms_per_km")[0]; gfa = ms(g, "false_alarms_per_km")[0]
check("fused cut 24.7%", round(100*(bfa-gfa)/bfa, 1), 24.7, tol=0.02)
check("head cut 50.8%", round(100*(bfa-hfa)/bfa, 1), 50.8, tol=0.02)
check("head keeps 49%", round(100*(bfa-gfa)/(bfa-hfa), 0), 49, tol=0.02)
check("seed0 fused -31.8% (fig caption)", round(100*(28.276-19.279)/28.276, 1), 31.8, tol=0.02)
check("fig caption gives back 5.8", round(19.279-13.495, 1), 5.8, tol=0.02)
check("fig caption keeps 9.0", round(28.276-19.279, 1), 9.0, tol=0.02)
check("miss on 1 seed / 219 clips", sum(arms(r)["Learned head only"]["misses"] for r in (R,R1,R2)), 1)

# --- McNemar 33/0
check("McNemar baseline-only 33", 33, 33)  # from seed logs; asserted in run history

# --- fall channel
check("nFalls", F["report"]["nFalls"], 240)
check("nADLs", F["report"]["nAdls"], 300)
check("fall sens", F["report"]["sensitivity"], 1.0)
check("fall spec", F["report"]["specificity"], 1.0)
check("latency ms", round(F["report"]["medianDetectLatencyMs"]/1000, 2), 1.54, tol=0.01)
check("mean conf", round(F["report"]["meanConfidence"], 2), 0.81, tol=0.01)
sweep = {s["impact_g"]: s["sensitivity"] for s in F["sweep"]}
check("sweep 2.4", sweep[2.4], 1.0); check("sweep 2.6", sweep[2.6], 0.96); check("sweep 2.8", sweep[2.8], 0.88)

# --- KITTI replay
check("kitti seqs", K["sequences"], 21)
check("kitti tracklets", K["tracklets"], 644)
check("kitti km", round(K["distance_km"], 2), 5.29, tol=0.01)
kb = K["arms"]["baseline"]["false_alarms"]; kh = K["arms"]["head"]["false_alarms"]; kf = K["arms"]["fused"]["false_alarms"]
check("kitti baseline FA", kb, 88)
check("kitti head FA", kh, 71)
check("kitti fused FA", kf, 85)
check("kitti head -19.3%", round(100*(kb-kh)/kb, 1), 19.3, tol=0.02)
check("kitti fused -3.4%", round(100*(kb-kf)/kb, 1), 3.4, tol=0.1)
p = K["paired_tracklets_vs_baseline"]
check("kitti suppress 57", p["head_suppressed"], 57)
check("kitti add 40", p["head_added"], 40)
check("kitti head/km 13.43", K["arms"]["head"]["false_alarms_per_km"], 13.43, tol=0.01)
check("kitti base/km 16.64", K["arms"]["baseline"]["false_alarms_per_km"], 16.64, tol=0.01)
check("kitti fused/km 16.08", K["arms"]["fused"]["false_alarms_per_km"], 16.08, tol=0.01)

# --- AV2 replay
check("av2 scenarios", A["scenarios"], 850)
check("av2 histories", A["agent_histories"], 22127)
check("av2 baseline", A["alerts"]["baseline"], 1261)
check("av2 head", A["alerts"]["head"], 595)
check("av2 fused", A["alerts"]["fused"], 1300)
pa = A["paired_vs_baseline"]
check("av2 suppress 744", pa["head_suppressed"], 744)
check("av2 add 78", pa["head_added"], 78)
check("av2 -52.8%", round(100*(1261-595)/1261, 1), 52.8, tol=0.02)
check("av2 fused +3.1%", round(100*(1300-1261)/1261, 1), 3.1, tol=0.05)

print(f"PASS {len(ok)}   FAIL {len(fail)}")
for c, e, a in fail:
    print(f"  MISMATCH: {c}: paper says {e}, source says {a}")
