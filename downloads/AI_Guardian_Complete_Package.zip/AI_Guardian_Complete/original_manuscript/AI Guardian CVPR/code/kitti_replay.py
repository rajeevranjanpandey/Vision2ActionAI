"""Replay of real urban-traffic trajectories (KITTI tracking) through the
decision stack.

What this is and is not
-----------------------
KITTI's tracking benchmark supplies 21 urban sequences at 10 Hz with
human-annotated 3D boxes for pedestrians, cyclists and vehicles, plus a
GPS/IMU stream. Box centres are given per frame in the (ego-relative)
camera frame, so finite differences of a tracklet's centre are relative
velocities -- the same quantity the on-device tracker produces after ego
compensation, ego rotation between frames included.

This module replays every real tracklet through the *exact* decision
stack of the paper -- geometric kernel, learned head, fused rule -- and
scores the arms on real traffic geometry:

* false alarms per km on real trajectories (the alarm-fatigue question),
* recall and lead time on the (rare) real breaches of the ego cylinder,
* how the simulated-traffic operating point behaves on real traffic.

It is still not a field trial: no wearable walked anywhere, the camera
is car-mounted at 1.65 m, and KITTI carries no "when should a warning
have been given" annotations. Breach ground truth here means the true
3D centre entering the ego cylinder, computed from the annotated future
-- exact for what it measures, and narrower than the paper's simulator
label because KITTI traffic almost never contacts its own ego vehicle.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..config import RiskConfig
from ..risk.learned import LearnedRiskHead
from ..train.features import FrameContext, WINDOW, track_features, window_of
from ..types import Track

KITTI_DT = 0.1  # KITTI tracking runs at 10 Hz, the same as the fast path

# Classes whose motion can close distance on the wearer; per the head's
# dynamic-class prior.
RELEVANT_CLASSES = {"Pedestrian": 0.5, "Cyclist": 0.6, "Car": 1.8,
                    "Van": 2.0, "Truck": 2.2}


@dataclass(slots=True)
class ReplayTrack:
    """One real tracklet, resampled onto consecutive observed frames."""

    seq_id: str
    kitti_id: int
    class_name: str
    frames: np.ndarray          # (T,) frame indices
    states: np.ndarray          # (T, 4) true ego-frame x, z, vx, vz
    width_m: float


def parse_sequence(seq_dir: Path, labels_dir: Path, min_frames: int = 6,
                   z_min: float = 0.8, z_max: float = 24.0) -> list[ReplayTrack]:
    """Parse one KITTI tracking sequence into ego-frame tracklets."""
    label_path = labels_dir / f"{seq_dir}.txt"
    if not label_path.exists():
        return []
    by_id: dict[int, dict[int, tuple[float, float, float, float, str]]] = {}
    for line in label_path.read_text().splitlines():
        p = line.split()
        if len(p) < 15:
            continue
        frame, tid, obj_type = int(p[0]), int(p[1]), p[2]
        if obj_type not in RELEVANT_CLASSES:
            continue
        # columns: frame track type trunc occ alpha bbox2d(4) h w l x y z rot_y score
        h, w, l = float(p[10]), float(p[11]), float(p[12])
        x, y, z = float(p[13]), float(p[14]), float(p[15])
        if not (z_min <= z <= z_max) or h <= 0 or w <= 0:
            continue
        by_id.setdefault(tid, {})[frame] = (x, z, y, w, obj_type)

    tracks: list[ReplayTrack] = []
    for tid, frames in by_id.items():
        fidx = np.array(sorted(frames))
        if len(fidx) < min_frames:
            continue
        # Drop tracklets with frame gaps > 1 s: a 10 Hz finite difference
        # across a 3 s gap fabricates velocity.
        if np.any(np.diff(fidx) > 10):
            continue
        states = np.zeros((len(fidx), 4))
        for i, f in enumerate(fidx):
            x, z, _y, w, obj = frames[int(f)]
            states[i, 0], states[i, 1] = x, z
        raw = np.zeros_like(states)
        raw[1:-1] = (states[2:] - states[:-2]) / (2 * KITTI_DT)
        raw[0] = (states[1] - states[0]) / KITTI_DT
        raw[-1] = (states[-1] - states[-2]) / KITTI_DT
        # Box-annotation jitter lands in the finite differences as velocity
        # noise far above the on-device Kalman filter's output. A causal
        # trailing average over 0.5 s reproduces the filter's variance
        # reduction without ever touching the future.
        vel = raw.copy()
        for i in range(len(raw)):
            lo = max(0, i - 4)
            vel[i] = raw[lo : i + 1].mean(axis=0)
        states = np.column_stack([states[:, 0], states[:, 1], vel[:, 0], vel[:, 1]])
        cls = frames[int(fidx[0])][4]
        tracks.append(ReplayTrack(
            seq_id=str(seq_dir), kitti_id=tid, class_name=cls,
            frames=fidx, states=states, width_m=RELEVANT_CLASSES[cls]))
    return tracks


def breach_times(states: np.ndarray, radius: float) -> np.ndarray:
    """Exact time-to-breach per frame from the annotated future, +inf if none."""
    n = states.shape[0]
    dist = np.hypot(states[:, 0], states[:, 1])
    ttb = np.full(n, np.inf)
    next_breach = np.inf
    for i in range(n - 1, -1, -1):
        if dist[i] <= radius:
            next_breach = 0.0
        ttb[i] = next_breach
        next_breach = next_breach + KITTI_DT if np.isfinite(next_breach) else np.inf
    return ttb


def _observe(state: np.ndarray, width: float, class_name: str, rng: np.random.Generator,
             cfg: RiskConfig) -> Track:
    """Corrupt a real tracklet sample with the paper's measurement-noise model."""
    x, z, vx, vz = state
    z_obs = z * (1.0 + rng.normal(0.0, 0.04)) + rng.normal(0.0, 0.05)
    x_obs = x + rng.normal(0.0, 0.03 * max(z, 1.0))
    v_sigma = 0.12 + 0.02 * max(z, 0.0)
    return Track(
        track_id=0,
        x_m=float(x_obs),
        z_m=float(max(z_obs, 0.05)),
        vx_mps=float(vx + rng.normal(0.0, v_sigma)),
        vz_mps=float(vz + rng.normal(0.0, v_sigma)),
        width_m=float(width),
        class_name=class_name,
        hits=5,
        covariance_trace=float(v_sigma ** 2 * 4),
    )


def score_sequence(tracks: list[ReplayTrack], head: LearnedRiskHead | None,
                   cfg: RiskConfig, rng: np.random.Generator,
                   inv_ttc_urgent: float = 1.0 / 2.0):
    """Run the four arms over one sequence's real tracklets.

    Returns per-track decisions as
    ``[(track, baseline_alert, head_alert, fused_alert, ttb_true), ...]``
    where each alert is the first frame index that fired (or None).
    """
    from ..train.features import HORIZON_S
    thr = head.threshold if head is not None else 0.5
    out = []
    for tr in tracks:
        radius = cfg.ego_radius_m + 0.5 * tr.width_m
        ttb = breach_times(tr.states, radius)
        labels = (ttb <= HORIZON_S).astype(np.float32)

        feats = np.zeros((len(tr.frames), 14), dtype=np.float32)
        for i, state in enumerate(tr.states):
            obs = _observe(state, tr.width_m, tr.class_name, rng, cfg)
            feats[i] = track_features(obs, cfg, FrameContext())

        # baseline: constant-velocity kernel at the warn threshold (TTC <= 2.0 s);
        # fused: geometry only inside the urgent gate (TTC <= 1.5 s), the head may
        # still fire earlier -- exactly the paper's rule, not a superset of it.
        base_fire = feats[:, 6] >= 1.0 / 2.5
        fused_geom = feats[:, 6] >= 1.0 / 2.0
        head_fire = None
        if head is not None and head.available:
            wins = np.stack([window_of(feats, t, WINDOW).reshape(-1)
                             for t in range(len(tr.frames))])
            p = head.predict_batch(wins)
            head_fire = p >= thr
        fused_fire = fused_geom | (head_fire if head_fire is not None else False)

        def first(mask):
            idx = np.flatnonzero(mask)
            return int(idx[0]) if idx.size else None

        out.append((tr, first(base_fire), first(head_fire) if head_fire is not None else None,
                    first(fused_fire), ttb))
    return out
