"""Replay of real agent-centric traffic histories (Argoverse 2 motion
forecasting scenarios, Hugging Face mirror saeedrmd/trajectory-prediction-argoverse2)
through the decision stack.

Each scenario holds 32 agents' true 2.0 s histories (21 frames at 10 Hz) in a
fixed, heading-aligned frame centred on a focal agent, plus the focal agent's
6 s future. The focal agent's pose at the last history frame plays the role of
the wearer at the origin; every other agent's history is a real ego-relative
trajectory through the unmodified decision stack.

What this corpus can and cannot measure: it carries no future annotations for
the non-focal agents, so there are no breach labels -- the replay measures
alert propensity on real traffic geometry (what fraction of real 2 s histories
each arm alerts on, and the paired suppress/add structure between arms), not
warning quality. Axis convention was verified empirically: the focal agent's
own displacement lies along +x in 97% of scenarios, so x is forward, y lateral.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

AV2_DT = 0.1  # 10 Hz
HISTORY_FRAMES = 21


@dataclass(slots=True)
class Av2Track:
    """One real agent history, ego-relative to the focal agent's end pose."""

    scenario: str
    agent_index: int
    states: np.ndarray  # (T, 4) x_forward, y_lateral, vx, vy -- causal smoothing applied
    valid: np.ndarray   # (T,) bool


def load_scenario(path: Path, smooth_frames: int = 5) -> tuple[list[Av2Track], int]:
    """Parse one scenario pickle into replayable agent histories.

    Returns (tracks, n_agents_total). The focal agent is skipped (it sits at
    the origin); agents with fewer than 3 valid positions are dropped.
    Velocities are finite differences followed by a causal trailing average,
    for the same reason as the KITTI replay: annotation/preprocessing jitter
    exceeds what the on-device Kalman filter would pass through.
    """
    import pickle

    d = pickle.load(open(path, "rb"))
    focal = int(d["track_index_to_predict"])
    trajs, masks = d["obj_trajs"], d["obj_trajs_mask"].astype(bool)
    tracks: list[Av2Track] = []
    for j in range(trajs.shape[0]):
        if j == focal:
            continue
        m = masks[j]
        idx = np.flatnonzero(m)
        if idx.size < 3:
            continue
        pos = trajs[j, idx, :]  # (T, 2) x forward, y lateral
        raw = np.zeros_like(pos)
        if len(pos) >= 2:
            raw[1:-1] = (pos[2:] - pos[:-2]) / (2 * AV2_DT)
            raw[0] = (pos[1] - pos[0]) / AV2_DT
            raw[-1] = (pos[-1] - pos[-2]) / AV2_DT
        vel = raw.copy()
        for i in range(len(raw)):
            lo = max(0, i - smooth_frames + 1)
            vel[i] = raw[lo : i + 1].mean(axis=0)
        states = np.column_stack([pos, vel])
        valid = np.zeros(len(pos), dtype=bool)
        valid[:] = True
        tracks.append(Av2Track(scenario=path.stem, agent_index=j,
                               states=states, valid=valid))
    return tracks, trajs.shape[0]


def _observe(state: np.ndarray, rng: np.random.Generator) -> "object":
    """Corrupt with the paper's measurement-noise model (unknown class/width)."""
    from ..types import Track

    x, y, vx, vy = state
    z_obs = x * (1.0 + rng.normal(0.0, 0.04)) + rng.normal(0.0, 0.05)
    y_obs = y + rng.normal(0.0, 0.03 * max(x, 1.0))
    v_sigma = 0.12 + 0.02 * max(x, 0.0)
    return Track(
        track_id=0,
        x_m=float(y_obs),
        z_m=float(max(z_obs, 0.05)),
        vx_mps=float(vy + rng.normal(0.0, v_sigma)),
        vz_mps=float(vx + rng.normal(0.0, v_sigma)),
        width_m=0.5,
        class_name="unknown",
        hits=5,
        covariance_trace=float(v_sigma ** 2 * 4),
    )
