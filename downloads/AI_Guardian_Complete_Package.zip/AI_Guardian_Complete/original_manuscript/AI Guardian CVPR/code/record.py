#!/usr/bin/env python3
"""Data collection for GuardianBench.

    python scripts/record.py --source 0 --route "market-street" --anonymize
    python scripts/record.py --source walk1.mp4 --imu walk1_imu.csv --route "campus-loop"

Writes the on-disk layout ``bench/dataset.py`` expects:

    root/
      clips/<clip_id>/frames/000000.jpg ...
      clips/<clip_id>/imu.npy            # (N, 4) = t, speed_mps, yaw_rate_rps, pitch_rad
      clips/<clip_id>/meta.json
      annotations/<clip_id>.json         # scaffold only -- filled by the O&M instructors

What this tool is deliberately *not*: it is not the study protocol. Collecting usable
hazard-onset data requires a sighted safety escort on every route, an O&M instructor
annotating onset frames afterwards, and IRB approval before the first walk with a
blind participant. This script only captures and cleans the sensor streams.

Anonymization runs at ingest, before anything touches disk, because the raw frames
should not survive on the recording laptop either. The Haar detectors are not perfect:
faces in profile, small plates, and plates at steep angles can survive the blur, so a
human pass over every clip is still required before release.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

RECORD_FPS = 30.0
CLIP_SECONDS = 20.0  # short clips keep annotation sessions manageable


def _participant_hash(participant: str) -> str:
    """One-way hash so meta.json never carries a raw participant id."""
    return hashlib.sha256(participant.encode()).hexdigest()[:16]


def _blur_regions(frame_bgr: np.ndarray, gray: np.ndarray, cascade, pad: float = 0.15) -> int:
    """Pixelate each detected region in place. Returns how many regions were hit."""
    if cascade is None or frame_bgr.size == 0:
        return 0
    hits = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(24, 24))
    h, w = frame_bgr.shape[:2]
    for x, y, rw, rh in hits:
        px, py = int(rw * pad), int(rh * pad)
        x0, y0 = max(0, x - px), max(0, y - py)
        x1, y1 = min(w, x + rw + px), min(h, y + rh + py)
        if x1 <= x0 or y1 <= y0:
            continue
        region = frame_bgr[y0:y1, x0:x1]
        # Downsample then upsample with nearest: destroys the face/plate, keeps the blur box visible
        # so annotators can see that something was redacted rather than silently missing.
        small = region[::8, ::8]
        frame_bgr[y0:y1, x0:x1] = np.repeat(
            np.repeat(small, 8, axis=0), 8, axis=1
        )[: y1 - y0, : x1 - x0]
    return len(hits)


def _load_cascades():
    import cv2

    face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    plate = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")
    # detectMultiScale on an untrained/failed load raises no error, it just misfires -- check explicitly.
    face = face if not face.empty() else None
    plate = plate if not plate.empty() else None
    return face, plate


def _read_imu_csv(path: Path) -> np.ndarray:
    """Load a (t, speed_mps, yaw_rate_rps, pitch_rad) CSV written by the IMU logger.

    Columns are positional; a header line starting with ``#`` or ``t`` is skipped. Any
    rows shorter than four columns are dropped rather than zero-filled -- a fabricated
    IMU sample is worse than a missing one, because the ground-plane estimator trusts it.
    """
    rows: list[list[float]] = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line[0].isalpha():
            continue
        parts = [p for p in line.replace(",", " ").split() if p]
        try:
            vals = [float(p) for p in parts[:4]]
        except ValueError:
            continue
        if len(vals) == 4:
            rows.append(vals)
    if not rows:
        raise SystemExit(f"no usable IMU rows in {path} -- need t, speed_mps, yaw_rate_rps, pitch_rad")
    return np.asarray(rows, dtype=np.float64)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", required=True,
                    help="camera index (e.g. 0) or a video file to ingest")
    ap.add_argument("--imu", type=Path, default=None,
                    help="optional IMU CSV: t, speed_mps, yaw_rate_rps, pitch_rad")
    ap.add_argument("--root", type=Path, default=Path("data/guardianbench"))
    ap.add_argument("--route", default="unnamed-route")
    ap.add_argument("--weather", default="dry")
    ap.add_argument("--participant", default="anon",
                    help="stored only as a salt-free SHA-256 prefix in meta.json")
    ap.add_argument("--clip-seconds", type=float, default=CLIP_SECONDS)
    ap.add_argument("--fps", type=float, default=RECORD_FPS)
    ap.add_argument("--anonymize", action="store_true",
                    help="blur faces and licence plates at ingest, before disk")
    args = ap.parse_args()

    import cv2

    source: int | str
    try:
        source = int(args.source)
    except ValueError:
        source = args.source
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"cannot open source {args.source!r}")
    if source == 0:
        # Live cameras drift from the nominal rate; force the value meta.json will claim.
        cap.set(cv2.CAP_PROP_FPS, args.fps)

    face_cascade, plate_cascade = _load_cascades() if args.anonymize else (None, None)
    if args.anonymize and face_cascade is None:
        print("warning: face cascade unavailable -- proceeding WITHOUT anonymization")

    imu = _read_imu_csv(args.imu) if args.imu else np.zeros((0, 4))
    ts_start = time.strftime("%Y%m%d-%H%M%S")
    route_slug = args.route.replace(" ", "-").lower()

    clip_idx = 0
    total_frames = 0
    blurred = 0
    while True:
        clip_id = f"{route_slug}-{ts_start}-{clip_idx:03d}"
        clip_dir = args.root / "clips" / clip_id
        frames_dir = clip_dir / "frames"
        frames_dir.mkdir(parents=True, exist_ok=True)

        target = int(args.clip_seconds * args.fps)
        saved = 0
        interval = max(1, int(round(cap.get(cv2.CAP_PROP_FPS) / args.fps))) if source != 0 else 1
        for i in range(target):
            ok = cap.grab()
            if not ok:
                break
            if i % interval:
                continue
            ok, frame = cap.retrieve()
            if not ok:
                break
            if args.anonymize:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                blurred += _blur_regions(frame, gray, face_cascade)
                blurred += _blur_regions(frame, gray, plate_cascade)
            cv2.imwrite(str(frames_dir / f"{saved:06d}.jpg"), frame,
                        [cv2.IMWRITE_JPEG_QUALITY, 92])
            saved += 1
        if saved == 0:
            if clip_idx == 0:
                raise SystemExit("no frames captured -- check the source and try again")
            # Trailing directory from a clean end-of-stream; do not leave it behind.
            frames_dir.rmdir()
            clip_dir.rmdir()
            break

        (clip_dir / "meta.json").write_text(json.dumps({
            "fps": args.fps,
            "route": args.route,
            "weather": args.weather,
            "participant": _participant_hash(args.participant),
            "anonymized": args.anonymize,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "frames": saved,
            "source": "camera" if source == 0 else str(args.source),
        }, indent=2))
        if imu.size:
            np.save(clip_dir / "imu.npy", imu)
        ann_dir = args.root / "annotations"
        ann_dir.mkdir(parents=True, exist_ok=True)
        (ann_dir / f"{clip_id}.json").write_text(json.dumps({
            "clip_id": clip_id,
            "hazards": [],
            "_note": "scaffold -- fill hazard onsets per the protocol in bench/dataset.py",
        }, indent=2))

        print(f"  {clip_id}: {saved} frames")
        total_frames += saved
        clip_idx += 1
        if source != 0:
            break  # ingest a file exactly once

    cap.release()
    print(f"done: {clip_idx} clip(s), {total_frames} frames, {blurred} region(s) blurred")
    print("next: O&M instructors annotate hazard onsets in annotations/<clip_id>.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
