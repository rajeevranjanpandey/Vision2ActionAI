#!/usr/bin/env python3
"""Replay real KITTI tracking trajectories through the decision stack.

    PYTHONPATH=. python3.10 scripts/replay_kitti.py --kitti /path/to/kitti/training

Scores baseline / head-only / fused arms on real urban-traffic tracklets
(false alarms per real km, recall and lead time on real breaches) and
writes artifacts/kitti_replay.json.
"""
from __future__ import annotations

import argparse, json, sys, time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from guardian.bench.kitti_replay import KITTI_DT, parse_sequence, score_sequence
from guardian.config import RiskConfig
from guardian.risk.learned import LearnedRiskHead
from guardian.train.trainer import load_ensemble

WALK_SPEED_MPS = 1.3  # km normalisation matches the simulator harness


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--kitti", type=Path, required=True,
                    help="KITTI tracking `training` dir (label_02 + oxts)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=Path, default=Path("artifacts/kitti_replay.json"))
    args = ap.parse_args()

    cfg = RiskConfig()
    labels_dir = args.kitti / "label_02"
    oxts_dir = args.kitti / "oxts"
    seqs = sorted(p.stem for p in labels_dir.glob("*.txt"))
    print(f"{len(seqs)} KITTI tracking sequences")

    # real distance from the GPS/IMU forward speed, integrated at 10 Hz
    km_by_seq = {}
    for s in seqs:
        speeds = []
        for line in (oxts_dir / f"{s}.txt").read_text().splitlines():
            p = line.split()
            vf, vl = float(p[6]), float(p[7])  # forward / leftward velocity m/s
            speeds.append(np.hypot(vf, vl))
        km_by_seq[s] = float(np.sum(speeds) * KITTI_DT / 1000.0)
    total_km = sum(km_by_seq.values())
    print(f"total real distance: {total_km:.2f} km")

    models, meta = load_ensemble("artifacts/risk_head.npz")
    head = LearnedRiskHead(temperature=float(meta["temperature"]),
                           threshold=float(meta["threshold"]))
    head._models = models
    rng = np.random.default_rng(args.seed)

    arms = {"baseline": {"fa": 0, "miss": 0, "leads": [], "late": 0},
            "head": {"fa": 0, "miss": 0, "leads": [], "late": 0},
            "fused": {"fa": 0, "miss": 0, "leads": [], "late": 0}}
    paired = {"head_added": 0, "head_suppressed": 0, "fused_added": 0, "fused_suppressed": 0}
    n_tracks = 0
    n_breach = 0
    t0 = time.time()
    for s in seqs:
        tracks = parse_sequence(s, labels_dir)
        n_tracks += len(tracks)
        decisions = score_sequence(tracks, head, cfg, rng)
        for tr, b, h, f, ttb in decisions:
            breach_idx = np.flatnonzero(np.isfinite(ttb) & (ttb <= 1e-6))
            has_breach = breach_idx.size > 0
            n_breach += 1 if has_breach else 0
            for name, alert in (("baseline", b), ("head", h), ("fused", f)):
                a = arms[name]
                if has_breach:
                    bi = int(breach_idx[0])
                    if alert is None or alert > bi:
                        a["miss"] += 1
                    else:
                        lead = (bi - alert) * KITTI_DT
                        a["leads"].append(lead)
                        a["late"] += 1 if lead < 1.0 else 0
                else:
                    a["fa"] += 1 if alert is not None else 0
            if not has_breach:
                if h is not None and b is None: paired["head_added"] += 1
                if b is not None and h is None: paired["head_suppressed"] += 1
                if f is not None and b is None: paired["fused_added"] += 1
                if b is not None and f is None: paired["fused_suppressed"] += 1
        if int(s) % 5 == 0:
            print(f"  seq {s}: {len(tracks)} tracklets ({time.time()-t0:.0f}s)")

    report = {
        "source": "KITTI tracking benchmark (label_02), real urban traffic",
        "sequences": len(seqs), "tracklets": n_tracks, "breach_tracklets": n_breach,
        "distance_km": round(total_km, 3),
        "noise_model": "same multiplicative depth / lateral / velocity corruption as the simulator",
        "arms": {},
        "paired_tracklets_vs_baseline": paired,
    }
    for name, a in arms.items():
        report["arms"][name] = {
            "false_alarms": a["fa"],
            "false_alarms_per_km": round(a["fa"] / max(total_km, 1e-9), 3),
            "breach_tracklets": n_breach,
            "misses": a["miss"],
            "late_alerts": a["late"],
            "median_lead_s": round(float(np.median(a["leads"])), 2) if a["leads"] else None,
            "p10_lead_s": round(float(np.percentile(a["leads"], 10)), 2) if a["leads"] else None,
        }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2))
    print(json.dumps(report["arms"], indent=2))
    print(f"wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
