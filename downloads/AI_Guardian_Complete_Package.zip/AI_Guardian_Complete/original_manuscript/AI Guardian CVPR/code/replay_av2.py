#!/usr/bin/env python3
"""Replay Argoverse 2 agent-centric histories (Hugging Face mirror) through
the decision stack.

    PYTHONPATH=. python3.10 scripts/replay_av2.py --av2mf /path/to/pickles

Scores baseline / head-only / fused alert propensity on ~26k real 2 s
ego-relative agent histories (no breach labels exist in this corpus) and
writes artifacts/av2_replay.json.
"""
from __future__ import annotations

import argparse, json, sys, time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from guardian.bench.av2_replay import AV2_DT, load_scenario, _observe  # noqa: E402

from guardian.config import RiskConfig  # noqa: E402
from guardian.risk.learned import LearnedRiskHead  # noqa: E402
from guardian.train.features import WINDOW, track_features, window_of, FrameContext  # noqa: E402
from guardian.train.trainer import load_ensemble  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--av2mf", type=Path, required=True, help="dir of sample_*.pkl scenarios")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--limit", type=int, default=0, help="cap scenarios (0 = all)")
    ap.add_argument("--out", type=Path, default=Path("artifacts/av2_replay.json"))
    args = ap.parse_args()

    cfg = RiskConfig()
    files = sorted(Path(args.av2mf).glob("sample_*.pkl"))
    if args.limit:
        files = files[: args.limit]
    models, meta = load_ensemble("artifacts/risk_head.npz")
    head = LearnedRiskHead(temperature=float(meta["temperature"]),
                           threshold=float(meta["threshold"]))
    head._models = models
    rng = np.random.default_rng(args.seed)
    thr = head.threshold
    INV = 6  # inverse-TTC feature index

    arms = {"baseline": 0, "head": 0, "fused": 0}
    paired = {"head_added": 0, "head_suppressed": 0, "fused_added": 0, "fused_suppressed": 0}
    n_tracks = 0
    t0 = time.time()
    for n, f in enumerate(files):
        tracks, _ = load_scenario(f)
        for tr in tracks:
            T = len(tr.states)
            # score only the last WINDOW frames: the causal decision window
            feats = np.zeros((T, 14), dtype=np.float32)
            for i, s in enumerate(tr.states):
                feats[i] = track_features(_observe(s, rng), cfg, FrameContext())
            base = feats[:, INV] >= 1.0 / 2.5
            fused_geom = feats[:, INV] >= 1.0 / 2.0
            wins = np.stack([window_of(feats, t, WINDOW).reshape(-1) for t in range(T)])
            p = head.predict_batch(wins)
            hf = p >= thr
            lo = max(0, T - WINDOW)  # only frames with a full causal window
            b_alert = bool(base[lo:].any())
            h_alert = bool(hf[lo:].any())
            f_alert = bool((fused_geom[lo:] | hf[lo:]).any())
            arms["baseline"] += b_alert
            arms["head"] += h_alert
            arms["fused"] += f_alert
            if h_alert and not b_alert: paired["head_added"] += 1
            if b_alert and not h_alert: paired["head_suppressed"] += 1
            if f_alert and not b_alert: paired["fused_added"] += 1
            if b_alert and not f_alert: paired["fused_suppressed"] += 1
            n_tracks += 1
        if n % 100 == 0:
            print(f"  {n}/{len(files)} scenarios, {n_tracks} histories ({time.time()-t0:.0f}s)")

    report = {
        "source": "Argoverse 2 motion-forecasting scenarios, Hugging Face mirror saeedrmd/trajectory-prediction-argoverse2",
        "scenarios": len(files),
        "agent_histories": n_tracks,
        "note": "no breach labels for non-focal agents: measures alert propensity on real geometry, not warning quality",
        "alert_rate_per_history": {k: round(v / max(n_tracks, 1), 4) for k, v in arms.items()},
        "alerts": arms,
        "paired_vs_baseline": paired,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
