"""Tests for the Argoverse 2 replay adapter."""

import pickle
from pathlib import Path

import numpy as np

from guardian.bench.av2_replay import load_scenario


def _write_scenario(path: Path):
    """Two agents + focal: closing object along +x (forward)."""
    T = 21
    trajs = np.zeros((3, T, 2))
    masks = np.zeros((3, T))
    # focal agent: at origin at t=T-1, moving forward 0.2 m/frame before that
    trajs[0, :, 0] = (T - 1 - np.arange(T)) * -0.2
    masks[0, :] = True
    # object 1: starts 10 m ahead, closing at 1 m/s -> 0.1 m/frame
    trajs[1, :, 0] = 10.0 - 0.1 * np.arange(T)
    trajs[1, :, 1] = 0.3
    masks[1, :] = True
    # object 2: only 2 valid frames -> dropped
    trajs[2, :2, 0] = [5.0, 4.9]
    masks[2, :2] = True
    d = {
        "obj_trajs": trajs,
        "obj_trajs_mask": masks,
        "center_gt_trajs": np.zeros((60, 2)),
        "center_gt_trajs_mask": np.ones(60),
        "center_gt_final_valid_idx": np.int64(59),
        "track_index_to_predict": np.int64(0),
    }
    pickle.dump(d, open(path, "wb"))


def test_load_scenario_skips_focal_and_short(tmp_path):
    p = tmp_path / "sample_000000.pkl"
    _write_scenario(p)
    tracks, n_agents = load_scenario(p)
    assert n_agents == 3
    assert len(tracks) == 1
    t = tracks[0]
    assert t.agent_index == 1
    assert len(t.states) == T if (T := 21) else True
    # closing at 1 m/s along forward
    assert abs(t.states[-1, 2] + 1.0) < 1e-6
    # lateral offset preserved
    assert abs(t.states[-1, 1] - 0.3) < 1e-6


def test_causal_smoothing_uses_only_past(tmp_path):
    p = tmp_path / "sample_000001.pkl"
    _write_scenario(p)
    tracks, _ = load_scenario(p)
    t = tracks[0]
    # frame 0 velocity must equal the raw first difference (nothing before it)
    assert abs(t.states[0, 2] + 1.0) < 1e-6
