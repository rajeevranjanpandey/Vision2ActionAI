#!/usr/bin/env python3
"""Figure 1: the two-path architecture and its asymmetric fusion contract."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

BLUE, ORANGE, RED, GREEN, GREY = "#0072B2", "#E69F00", "#D55E00", "#009E73", "#666666"
fig, ax = plt.subplots(figsize=(3.45, 4.0))
ax.set_xlim(0, 106); ax.set_ylim(0, 126); ax.axis("off")

def box(x, y, w, h, text, ec, fc="white", fs=6.3, ls="-", weight="normal"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.7",
                                linewidth=0.9, edgecolor=ec, facecolor=fc, linestyle=ls))
    ax.text(x + w/2, y + h/2, text, ha="center", va="center", fontsize=fs,
            color="black", weight=weight, linespacing=1.3)

def arrow(x1, y1, x2, y2, color=GREY, style="-", lw=1.0):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                                 mutation_scale=7, linewidth=lw, color=color, linestyle=style))

# ---- fast path column (left)
ax.text(16, 123, "fast path · 10 Hz · 30 ms", ha="center", fontsize=6.6, weight="bold", color=BLUE)
box(2, 107, 28, 10, "Camera 30 fps\nIMU 50 Hz", GREY, fs=6.2)
box(2, 90, 28, 10, "Detect\nRT-DETR / YOLOv10", BLUE)
box(2, 72, 28, 11, "Metric depth\nDA-V2 + RANSAC\n+ IMU pitch", BLUE, fs=6.1)
box(2, 54, 28, 10, "3D tracks\nKalman + Hungarian", BLUE)
box(2, 37, 28, 10, "TTC kernel\nclosed form + severity", BLUE, weight="bold", fs=6.2)
arrow(16, 107, 16, 100.8); arrow(16, 90, 16, 83.8)
arrow(16, 72, 16, 64.8); arrow(16, 54, 16, 47.8)

# ---- learned head (right)
ax.text(79, 123, "learned head", ha="center", fontsize=6.6, weight="bold", color=ORANGE)
box(64, 47, 40, 60, "8$\\times$14 causal window\n(0.8 s)\n\n5-member\nMLP ensemble\n\ntemperature scaling\n\nconformal\nthreshold $\\alpha$", ORANGE, fs=6.1)
ax.text(84, 112, "may escalate,\nmay suppress", ha="center", fontsize=6.1, color=ORANGE, style="italic")

# ---- fusion block (centre), tall enough for its text
box(36, 34, 24, 64, "Asymmetric\nfusion\n\nurgent\nTTC $\\leq$1.5 s\ngeometry\nwins (veto)\n\n$\\hat{p}\\geq$0.75\nescalate\n\n$\\hat{p}+2\\sigma\\leq$0.15\n$\\sigma\\leq$0.18\nnon-urgent:\nsuppress", RED, fs=5.6)
arrow(30, 41, 36, 41, RED)
arrow(64, 67, 60, 67, ORANGE)

# ---- policy + output
box(34, 18, 28, 10, "Alert policy\nhysteresis,\ncooldown", BLUE, fs=5.5)
arrow(48, 37, 48, 28.8, RED)
box(0, 18, 30, 10, "Bone-conduction\naudio + haptics", GREEN, fs=6.0)
arrow(34, 23, 30, 23, GREY)

# ---- slow path
box(64, 18, 42, 10, "Slow path 0.5–1 Hz\nVLM · grounding\n· Whisper", GREY, fs=5.4, ls="--")
ax.text(84, 11.5, "advisory only — never in the safety loop", ha="center", fontsize=5.9, color=GREY, style="italic")

fig.savefig("fig/architecture.pdf", bbox_inches="tight")
fig.savefig("fig/architecture.png", dpi=300, bbox_inches="tight")
print("architecture figure v3 written")
