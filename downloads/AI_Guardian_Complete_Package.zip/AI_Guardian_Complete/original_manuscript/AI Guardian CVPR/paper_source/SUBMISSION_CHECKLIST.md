# CVPR 2027 Submission Checklist — AI Guardian paper

Target: CVPR 2027 main track. Registration ~Nov 13, full paper ~mid-Nov 2026
(tracker estimates — **confirm the official dates on cvpr.thecvf.com before relying on them**).

## Ready (done, verified)

- ✅ 8 content pages + references, official `cvpr.sty` (review mode), 0 LaTeX errors,
  0 overfull boxes, 9/9 automated build checks green
- ✅ Anonymity: author block anonymous; PDF metadata Author/Title empty; **zero** URIs;
  no GitHub/Lovable/personal strings in decompressed content
- ✅ Integrity scan: no invisible text (Tr 3), no white-on-white, no optional-content
  layers, no embedded files, no JavaScript, no prompt-injection-style strings
- ✅ Screenshot metadata: no EXIF, ICC profile only; no visible identity in figures
- ✅ References: 31 entries, all verified real; published venues used where they exist;
  preprints labeled as preprints
- ✅ Reproducibility substance in Sec 5.1 (seeds, config, hardware, one-command reruns);
  every number traces to a released result file

## Author tasks before the deadline

1. **Register on the CVPR portal** by the registration deadline (title + abstract + authors).
   Copy the abstract exactly from the PDF.
2. **Enter the paper ID** in `main.tex` (`\def\paperID{...}`) and rebuild.
3. **Authors block** stays anonymous for review; prepare the camera-ready un-redaction
   (names/affiliations) separately.
4. **Funding / competing interests** statements in the portal form.
5. **Reproducibility checklist** form in the portal (substance already in Sec 5.1).
6. **Re-read the official CVPR 2027 CFP** when posted: page limit (currently 8 + refs),
   AI/LLM-usage policy (CVPR 2027 CFP says LLMs are used in reviewing; check the exact
   author-side disclosure wording against Sec 8's paragraph), dual-submission rules.
7. **Similarity check** (iThenticate/Turnitin via the university) — run once on the final PDF.
8. **arXiv preprint (recommended):** `main-arxiv.tex` / `AI_Guardian_arXiv.pdf` are ready
   (public mode, page numbers). Replace the anonymous author block with the real one
   before posting. Post after portal registration.

## Files in this folder

| File | Purpose |
|---|---|
| `main.tex` / `AI_Guardian_CVPR.pdf` | the review submission (use this one) |
| `main-arxiv.tex` / `AI_Guardian_arXiv.pdf` | public/arXiv variant (page numbers, no review header) |
| `refs.bib` | 31 verified references |
| `cvpr.sty`, `ieeenat_fullname.bst`, `silence.sty` | official template files |
| `make_figures.py`, `make_architecture.py` | regenerate every figure from the data |
| `fig/` | all figure sources (PDF + PNG) |
| `verify.sh` | 9-check build verification harness |

## The two-track plan

- **Now:** main-track submission. Expected: real reviews; outcome uncertain.
- **Nov → Mar:** collect a small egocentric hazard-onset set (`code/record.py` + written
  protocol; IRB + O&M instructor required).
- **Spring 2027:** submit the strengthened version to a CVPR 2027 workshop
  (accessibility / vision-for-social-good) — the realistic acceptance path.

## Rebuild commands

```sh
# paper (review version)
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
# arXiv variant
pdflatex main-arxiv.tex && bibtex main-arxiv && pdflatex main-arxiv.tex && pdflatex main-arxiv.tex
# verification harness (9 checks)
./verify.sh 1
```

Requires TeX with the cvpr.sty dependencies (silence, lineno, cleveref, grfext, algorithms).
