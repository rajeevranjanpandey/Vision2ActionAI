#!/bin/bash
# One full verification iteration
cd /Users/rajvivan/.zcode/workspace/default/paper
rm -f main.aux main.bbl main.blg main.out main.log
pdflatex -interaction=nonstopmode main.tex > /tmp/v1.log 2>&1
bibtex main > /tmp/vb.log 2>&1
pdflatex -interaction=nonstopmode main.tex > /tmp/v2.log 2>&1
pdflatex -interaction=nonstopmode main.tex > /tmp/v3.log 2>&1
PASS=0; FAIL=0
check() { if eval "$2" > /dev/null 2>&1; then echo "  [PASS] $1"; PASS=$((PASS+1)); else echo "  [FAIL] $1"; FAIL=$((FAIL+1)); fi }
echo "iteration $1:"
check "no LaTeX errors"        "! grep -qE '^!' /tmp/v3.log"
check "no undefined refs"      "! grep -qi undefined /tmp/v3.log"
check "no overfull boxes"      "! grep -q 'Overfull' /tmp/v3.log"
check "no bibtex warnings"     "! grep -qiE 'warning|error' /tmp/vb.log"
REFSPAGE=$(python3.10 /tmp/refspage.py)
check "refs start page 9 (8pp content)" "[[ $REFSPAGE == 9 ]]"
check "content ends by page 8 (CVPR limit)" "[[ $REFSPAGE -le 9 ]]"
check "no TODO/FIXME/placeholder" "! pdftotext main.pdf - | grep -qiE 'TODO|FIXME|Lorem|\\\\[\\[RESULT|\\\\[cite|insert number'"
check "no broken ?? refs in PDF" "! pdftotext main.pdf - | grep -q '??'"
check "banned words absent" "! pdftotext main.pdf - | grep -qiE 'delve|crucial|furthermore|moreover|utilize|leverage|seamless|myriad|testament to|paradigm shift|state-of-the-art|it is worth noting|novel '"
echo "  -> $PASS passed, $FAIL failed"
